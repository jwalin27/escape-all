package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/escape-all/cyber-lms/internal/config"
	"github.com/escape-all/cyber-lms/internal/server"
	"github.com/escape-all/cyber-lms/pkg/auth"
	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/db"
	"github.com/escape-all/cyber-lms/pkg/lesson"
	"github.com/escape-all/cyber-lms/pkg/progress"
	"github.com/escape-all/cyber-lms/pkg/quiz"
	"github.com/escape-all/cyber-lms/pkg/tenant" // Import the tenant package
	"github.com/escape-all/cyber-lms/pkg/user"
)

func main() {
	ctx := context.Background()

	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	database, err := db.Connect(ctx, cfg.Database.URL)
	if err != nil {
		log.Fatalf("connect db: %v", err)
	}
	defer database.Close()

	userStore := user.NewStore(database)
	authService := auth.NewService(userStore, cfg)
	courseStore := course.NewStore(database)
	lessonStore := lesson.NewStore(database)
	progressStore := progress.NewStore(database)
	quizStore := quiz.NewStore(database)
	tenantStore := tenant.NewStore(database) // Create tenantStore instance

	if err := db.RunMigrations(cfg.Database.URL, cfg.Migrations.Dir); err != nil {
		log.Fatalf("run migrations: %v", err)
	}

	srv := &http.Server{
		Addr: cfg.Server.Address,
		Handler: server.NewRouter(server.Dependencies{
			DB:            database,
			AuthService:   authService,
			CourseStore:   courseStore,
			LessonStore:   lessonStore,
			ProgressStore: progressStore,
			QuizStore:     quizStore,
			TenantStore:   tenantStore, // Add TenantStore to Dependencies
		}),
	}

	idle := make(chan os.Signal, 1)
	signal.Notify(idle, os.Interrupt, syscall.SIGTERM)

	go func() {
		log.Printf("listening on %s", cfg.Server.Address)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("server error: %v", err)
		}
	}()

	<-idle

	ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		log.Printf("graceful shutdown failed: %v", err)
	}
}
