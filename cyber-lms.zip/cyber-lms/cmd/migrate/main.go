package main

import (
	"log"

	"github.com/escape-all/cyber-lms/internal/config"
	"github.com/escape-all/cyber-lms/pkg/db"
)

func main() {
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	if err := db.RunMigrations(cfg.Database.URL, cfg.Migrations.Dir); err != nil {
		log.Fatalf("run migrations: %v", err)
	}

	log.Println("migrations applied")
}
