ALTER TABLE quiz_attempts ADD COLUMN tenant_id UUID REFERENCES tenants(id);
