ALTER TABLE quiz_attempts DROP COLUMN tenant_id;
