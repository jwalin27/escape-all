ALTER TABLE users DROP COLUMN tenant_id;
