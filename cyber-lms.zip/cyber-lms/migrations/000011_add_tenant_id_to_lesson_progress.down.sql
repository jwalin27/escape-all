ALTER TABLE lesson_progress DROP COLUMN tenant_id;
