ALTER TABLE courses DROP COLUMN tenant_id;
