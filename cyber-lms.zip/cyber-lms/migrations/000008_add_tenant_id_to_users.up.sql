ALTER TABLE users ADD COLUMN tenant_id UUID REFERENCES tenants(id);
