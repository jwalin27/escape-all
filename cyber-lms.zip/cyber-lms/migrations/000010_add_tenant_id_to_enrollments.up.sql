ALTER TABLE enrollments ADD COLUMN tenant_id UUID REFERENCES tenants(id);
