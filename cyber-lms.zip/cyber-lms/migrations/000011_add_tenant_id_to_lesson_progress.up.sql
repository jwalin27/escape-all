ALTER TABLE lesson_progress ADD COLUMN tenant_id UUID REFERENCES tenants(id);
