ALTER TABLE quizzes ADD COLUMN tenant_id UUID REFERENCES tenants(id);
