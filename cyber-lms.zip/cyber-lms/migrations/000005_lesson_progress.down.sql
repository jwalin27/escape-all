DROP TABLE IF EXISTS lesson_progress;
