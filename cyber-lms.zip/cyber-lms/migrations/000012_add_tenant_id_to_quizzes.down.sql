ALTER TABLE quizzes DROP COLUMN tenant_id;
