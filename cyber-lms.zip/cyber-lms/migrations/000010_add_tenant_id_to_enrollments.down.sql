ALTER TABLE enrollments DROP COLUMN tenant_id;
