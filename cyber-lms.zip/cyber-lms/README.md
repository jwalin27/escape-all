# Cyber LMS

Monorepo scaffold for a Go backend and Vite-powered React frontend.

## Backend

- `go run ./cmd/api` – launches the HTTP server after running Postgres migrations.
- Config is resolved via `configs/config.yaml` plus `CYBER_LMS_*` environment overrides (`CYBER_LMS_DATABASE_URL`, `CYBER_LMS_MIGRATIONS_DIR`, `CYBER_LMS_SERVER_ADDRESS`, etc.).
- Health checks are exposed at `/health` and `/ready`.
- Authentication endpoints:
  - `POST /auth/register` (role-aware signup)
  - `POST /auth/login`
  - `POST /auth/logout`
  - `GET /auth/me`
  - `GET /dashboard/learner` and `/dashboard/instructor` enforce RBAC via JWTs
- Course domain:
  - `GET /courses` and `GET /courses/:id` for catalog access
  - `POST /courses` and `PUT /courses/:id` for instructors/admins to create/edit
  - `POST /courses/:id/enroll` plus `GET /me/enrollments` for learners
  - `POST /courses/:id/lessons` and `PUT /lessons/:id` so instructors can stage lesson content
  - `GET /courses/:id/lessons` and `GET /lessons/:id` restricted to enrolled users
  - `POST /lessons/:id/complete` plus `/courses/:id/progress` and `/instructor/courses/:id/progress` track per-lesson completion counts and percentages
  - `POST /lessons/:id/quiz`, `GET /lessons/:id/quiz`, `POST /quizzes/:id/attempts`, and `/instructor/courses/:id/report` manage auto-graded multiple-choice quizzes and reporting

## Frontend

- Located under `frontend/`.
- Run `npm install` then `npm run dev` to start the Vite server, or `npm run build` for production bundles.
- The React app provides routing, navigation, and a skeleton auth context/API client.
- Additional frontend surfaces include:
  - course catalog/detail/enrollment flows
  - course player with lesson list + content
  - instructor lesson builder and “My Courses” lists tied to the new APIs
- Progress trackers show checkmarks, completion percent, and a “Mark complete” CTA so learners see progress across all course surfaces.
- Quiz UX includes a multiple-choice form, result screen, and instructor report table so outcomes are measurable.
-
## Containers

- Backend image: `Dockerfile.api`.
- Frontend image: `frontend/Dockerfile`.
- Use `docker-compose up` to start the API and Postgres stack locally.

## CI (GitHub Actions)

- Lints the frontend (`npm run lint`).
- Runs `go test ./...` and builds `cmd/api`.
- Validates migrations via `go run ./cmd/migrate` using the `CYBER_LMS_*` env settings.
-
## Development helpers

- Config loader uses `viper` so `CONFIG_PATH` may point to an alternative config file.
- Postgres migrations live under `migrations/` and are applied at startup and via `cmd/migrate`.
