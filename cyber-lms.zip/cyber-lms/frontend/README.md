## Frontend

This is a Vite-powered React application that hosts the UI for Cyber LMS. The entry points are under `src/`, with routing in `router.tsx` plus context-managed authentication scaffolding.

### Available Scripts

- `npm install` – install dependencies defined in `package.json`.
- `npm run dev` – start the dev server (`http://localhost:5173` by default).
- `npm run build` – type check and build a production bundle.
- `npm run lint` – run ESLint against the TypeScript sources.

### Configuration

Copy `.env.example` to `.env` to customize the `VITE_API_BASE_URL` value for the backend API.
