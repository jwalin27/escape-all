/** @type {import('tailwindcss').Config} */
const defaultTheme = require('tailwindcss/defaultTheme');

module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'background-light': '#ffffff',
        'foreground-light': '#171717',
        'body-bg-light': '#ece7dd',
        'body-color-light': '#1a1a1a',
        'background-dark': '#0a0a0a',
        'foreground-dark': '#ededed',
      },
      fontFamily: {
        sans: ["Special Elite", ...defaultTheme.fontFamily.sans],
        mono: ["Special Elite", ...defaultTheme.fontFamily.mono],
      },
    },
  },
  plugins: [],
}
