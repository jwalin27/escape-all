import { createContext, ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { ApiClient, API_BASE_URL } from '../api/client';
import { AuthApi, AuthUser, AuthResponse, LoginPayload, RegisterPayload } from '../api/auth';

const TOKEN_KEY = 'cyber_lms_token';

const readToken = () => {
  if (typeof window === 'undefined') {
    return null;
  }
  return window.localStorage.getItem(TOKEN_KEY);
};

const persistToken = (token: string | null) => {
  if (typeof window === 'undefined') {
    return;
  }

  if (token) {
    window.localStorage.setItem(TOKEN_KEY, token);
    return;
  }

  window.localStorage.removeItem(TOKEN_KEY);
};

type AuthContextValue = {
  user: AuthUser | null;
  initializing: boolean;
  login: (input: LoginPayload) => Promise<void>;
  register: (input: RegisterPayload) => Promise<void>;
  logout: () => Promise<void>;
  client: ApiClient;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

type Props = {
  children: ReactNode;
};

const createTokenProvider = () => () => readToken();

const mapAuthResponse = (resp: AuthResponse) => {
  persistToken(resp.token);
  return resp.user;
};

export const AuthProvider = ({ children }: Props) => {
  const client = useMemo(() => new ApiClient(API_BASE_URL, createTokenProvider()), []);
  const authApi = useMemo(() => new AuthApi(client), [client]);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    const token = readToken();
    if (!token) {
      setInitializing(false);
      return;
    }

    let canceled = false;
    authApi
      .me()
      .then((profile) => {
        if (!canceled) {
          setUser(profile);
        }
      })
      .catch(() => {
        persistToken(null);
      })
      .finally(() => {
        if (!canceled) {
          setInitializing(false);
        }
      });

    return () => {
      canceled = true;
    };
  }, [authApi]);

  const login = async (input: LoginPayload) => {
    const resp = await authApi.login(input);
    setUser(mapAuthResponse(resp));
  };

  const register = async (input: RegisterPayload) => {
    const resp = await authApi.register(input);
    setUser(mapAuthResponse(resp));
  };

  const logout = async () => {
    await authApi.logout().catch(() => {});
    persistToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, initializing, login, register, logout, client }}>{children}</AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};
