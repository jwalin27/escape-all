import React from 'react';
import { Routes, Route } from 'react-router-dom';
import CourseCatalog from './pages/CourseCatalog';
import CourseDetail from './pages/CourseDetail';
import CourseLessonBuilder from './pages/CourseLessonBuilder';
import CoursePlayer from './pages/CoursePlayer';
import DashboardPage from './pages/Dashboard';
import HomePage from './pages/Home';
import InstructorCourseForm from './pages/InstructorCourseForm';
import InstructorDashboard from './pages/InstructorDashboard';
import InstructorReport from './pages/InstructorReport';
import LearnerDashboard from './pages/LearnerDashboard';
import LoginPage from './pages/Login';
import MyCourses from './pages/MyCourses';
import ProtectedRoute from './components/ProtectedRoute';
import QuizPage from './pages/QuizPage';
import RegisterPage from './pages/Register';

const AppRoutes: React.FC = () => (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/courses" element={<CourseCatalog />} />
      <Route path="/courses/:id" element={<CourseDetail />} />
      <Route
        path="/courses/:id/player"
        element={
          <ProtectedRoute roles={['learner', 'instructor', 'admin']}>
            <CoursePlayer />
          </ProtectedRoute>
        }
      />
      <Route
        path="/courses/:id/lessons/manage"
        element={
        <ProtectedRoute roles={['instructor', 'admin']}>
          <CourseLessonBuilder />
        </ProtectedRoute>
      }
    />
      <Route
        path="/lessons/:lessonId/quiz"
        element={
          <ProtectedRoute roles={['learner', 'instructor', 'admin']}>
            <QuizPage />
          </ProtectedRoute>
        }
      />
      <Route
        path="/courses/new"
        element={
          <ProtectedRoute roles={['instructor', 'admin']}>
            <InstructorCourseForm />
          </ProtectedRoute>
        }
      />
      <Route
        path="/my-courses"
        element={
          <ProtectedRoute roles={['learner', 'instructor', 'admin']}>
            <MyCourses />
          </ProtectedRoute>
        }
      />
      <Route
        path="/instructor/courses/:courseId/report"
        element={
          <ProtectedRoute roles={['instructor', 'admin']}>
            <InstructorReport />
          </ProtectedRoute>
        }
      />
      <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
      <Route
        path="/dashboard/learner"
        element={
          <ProtectedRoute roles={['learner']}>
            <LearnerDashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/dashboard/instructor"
        element={
          <ProtectedRoute roles={['instructor', 'admin']}>
            <InstructorDashboard />
          </ProtectedRoute>
        }
      />
    </Routes>
);

export default AppRoutes;
