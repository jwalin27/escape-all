import AppRoutes from './router';
import AppLayout from './layouts/AppLayout';

function App() {
  return (
    <AppLayout>
      <AppRoutes />
    </AppLayout>
  );
}

export default App;
