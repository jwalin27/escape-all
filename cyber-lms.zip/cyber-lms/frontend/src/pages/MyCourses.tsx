import { useEffect, useMemo, useState } from 'react';
import { CourseApi } from '../api/courses';
import { useAuth } from '../contexts/AuthContext';

const MyCourses = () => {
  const { client } = useAuth();
  const courseApi = useMemo(() => new CourseApi(client), [client]);
  const [courses, setCourses] = useState<Awaited<ReturnType<CourseApi['myEnrollments']>>>([]);
  const [loading, setLoading] = useState(true);
  const [progressMap, setProgressMap] = useState<Record<number, number>>({});

  useEffect(() => {
    courseApi
      .myEnrollments()
      .then((data) => setCourses(data))
      .finally(() => setLoading(false));
  }, [courseApi]);

  useEffect(() => {
    if (!courses.length) {
      setProgressMap({});
      return;
    }

    Promise.all(courses.map((course) => courseApi.progress(course.id)))
      .then((results) => {
        const map: Record<number, number> = {};
        results.forEach((result, idx) => {
          map[courses[idx].id] = result.percent;
        });
        setProgressMap(map);
      })
      .catch(() => {
        setProgressMap({});
      });
  }, [courses, courseApi]);

  if (loading) {
    return <p className="p-8">Loading your courses…</p>;
  }

  if (!courses.length) {
    return <p className="p-8">You have not enrolled in any courses yet.</p>;
  }

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">My Courses</h1>
      <ul className="space-y-4">
        {courses.map((course) => (
          <li key={course.id} className="bg-white p-4 shadow rounded-lg">
            <strong className="text-xl">{course.title}</strong>
            <p className="text-gray-700">{course.description}</p>
            <div className="w-full bg-gray-200 rounded-full h-1.5 mt-2">
              <div
                className="bg-blue-600 h-1.5 rounded-full"
                style={{ width: `${progressMap[course.id] ?? 0}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-600 mt-1">{progressMap[course.id] ?? 0}% complete</p>
          </li>
        ))}
      </ul>
    </section>
  );
};

export default MyCourses;