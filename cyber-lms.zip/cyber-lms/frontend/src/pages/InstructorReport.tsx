import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { QuizApi, InstructorReportResponse } from '../api/quiz';
import { useAuth } from '../contexts/AuthContext';

const InstructorReport = () => {
  const { client } = useAuth();
  const params = useParams<{ courseId: string }>();
  const courseId = Number(params.courseId);
  const quizApi = useMemo(() => new QuizApi(client), [client]);
  const [report, setReport] = useState<InstructorReportResponse | null>(null);
  const [status, setStatus] = useState('Loading report…');

  useEffect(() => {
    if (!Number.isFinite(courseId)) {
      return;
    }

    quizApi
      .report(courseId)
      .then((data) => {
        setReport(data);
        setStatus('');
      })
      .catch(() => setStatus('Unable to load report'));
  }, [courseId, quizApi]);

  if (!report) {
    return <p className="p-8">{status}</p>;
  }

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Course report</h1>
      <p className="text-sm text-gray-700 mb-4">{status || 'Report ready'}</p>
      <table className="min-w-full bg-white shadow rounded-lg overflow-hidden">
        <tbody>
          <tr className="border-b">
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Enrolled</th>
            <td className="py-3 px-4 text-gray-800">{report.enrolled}</td>
          </tr>
          <tr className="border-b">
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Total lessons</th>
            <td className="py-3 px-4 text-gray-800">{report.total_lessons}</td>
          </tr>
          <tr className="border-b">
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Avg completion</th>
            <td className="py-3 px-4 text-gray-800">{report.completion_pct}%</td>
          </tr>
          <tr className="border-b">
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Avg quiz score</th>
            <td className="py-3 px-4 text-gray-800">{report.average_score.toFixed(1)}</td>
          </tr>
          <tr>
            <th className="text-left py-3 px-4 font-semibold text-gray-700">Total completions</th>
            <td className="py-3 px-4 text-gray-800">{report.completed_entries}</td>
          </tr>
        </tbody>
      </table>
    </section>
  );
};

export default InstructorReport;