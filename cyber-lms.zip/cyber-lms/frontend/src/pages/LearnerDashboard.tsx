import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const LearnerDashboard = () => {
  const { client } = useAuth();
  const [message, setMessage] = useState('Loading learner content...');

  useEffect(() => {
    let cancelled = false;

    client
      .request<{ message: string }>('/dashboard/learner')
      .then((data) => {
        if (!cancelled) {
          setMessage(data.message);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setMessage('Unable to load learner details.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, [client]);

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Learner Dashboard</h1>
      <p className="text-lg">{message}</p>
    </section>
  );
};

export default LearnerDashboard;