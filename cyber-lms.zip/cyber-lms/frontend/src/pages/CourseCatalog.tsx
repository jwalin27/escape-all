import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CourseApi } from '../api/courses';
import { useAuth } from '../contexts/AuthContext';

const CourseCatalog = () => {
  const { client } = useAuth();
  const courseApi = useMemo(() => new CourseApi(client), [client]);
  const [search, setSearch] = useState('');
  const [courses, setCourses] = useState<Awaited<ReturnType<CourseApi['list']>>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    courseApi
      .list(search)
      .then((items) => setCourses(items))
      .finally(() => setLoading(false));
  }, [courseApi, search]);

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Course Catalog</h1>
      <label className="block mb-4">
        Search
        <input
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search titles or descriptions"
        />
      </label>
      {loading ? (
        <p>Loading courses…</p>
      ) : courses.length === 0 ? (
        <p>No courses match yet.</p>
      ) : (
        <ul className="space-y-4">
          {courses.map((course) => (
            <li key={course.id} className="bg-white p-4 shadow rounded-lg">
              <Link to={`/courses/${course.id}`} className="text-blue-600 hover:underline text-xl font-semibold">
                <strong>{course.title}</strong>
              </Link>
              <p className="text-gray-700">{course.description}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default CourseCatalog;