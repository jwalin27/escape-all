import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CourseApi, Course } from '../api/courses';
import { useAuth } from '../contexts/AuthContext';

const CourseDetail = () => {
  const { client, user } = useAuth();
  const params = useParams<{ id: string }>();
  const courseId = Number(params.id);
  const courseApi = useMemo(() => new CourseApi(client), [client]);
  const [course, setCourse] = useState<Course | null>(null);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(true);
  const [enrolled, setEnrolled] = useState(false);

  useEffect(() => {
    if (!Number.isFinite(courseId)) {
      return;
    }

    courseApi
      .get(courseId)
      .then((data) => setCourse(data))
      .catch(() => setStatus('Unable to load course'))
      .finally(() => setLoading(false));
  }, [courseApi, courseId]);

  const handleEnroll = async () => {
    try {
      const response = await courseApi.enroll(courseId);
      setStatus(response.message ?? response.status ?? 'Enrolled');
      setEnrolled(true);
    } catch {
      setStatus('Enrollment failed');
    }
  };

  if (loading) {
    return <p className="p-8">Loading course...</p>;
  }

  if (!course) {
    return <p className="p-8">Course not found.</p>;
  }

  const normalizedRole = user?.role?.toLowerCase();
  const isInstructor = normalizedRole === 'instructor' || normalizedRole === 'admin';

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
      <p className="text-lg mb-2">{course.description}</p>
      <p className="text-gray-600 mb-4">
        Instructor ID: {course.instructor_id} &middot; {course.published ? 'Published' : 'Draft'}
      </p>
      {user ? (
        <>
          <button
            type="button"
            onClick={handleEnroll}
            disabled={enrolled}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50 disabled:cursor-not-allowed mb-4"
          >
            {enrolled ? 'Enrolled' : 'Enroll now'}
          </button>
          {status && <p className="text-sm text-gray-700 mb-4">{status}</p>}
          <p className="mb-2">
            <Link to={`/courses/${course.id}/player`} className="text-blue-600 hover:underline">
              Open course player
            </Link>
          </p>
          {isInstructor && (
            <p>
              <Link to={`/courses/${course.id}/lessons/manage`} className="text-blue-600 hover:underline">
                Manage lessons
              </Link>
            </p>
          )}
        </>
      ) : (
        <p className="text-lg">
          <Link to="/login" className="text-blue-600 hover:underline">
            Sign in
          </Link>{' '}
          to enroll.
        </p>
      )}
    </section>
  );
};

export default CourseDetail;