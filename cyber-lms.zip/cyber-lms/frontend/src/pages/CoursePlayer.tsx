import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Course, CourseApi, CourseProgressResponse } from '../api/courses';
import { Lesson, LessonApi } from '../api/lessons';
import { useAuth } from '../contexts/AuthContext';

const CoursePlayer = () => {
  const { client } = useAuth();
  const { id } = useParams<{ id: string }>();
  const courseId = Number(id);
  const courseApi = useMemo(() => new CourseApi(client), [client]);
  const lessonApi = useMemo(() => new LessonApi(client), [client]);
  const [course, setCourse] = useState<Course | null>(null);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [status, setStatus] = useState('Loading lessons...');
  const [progress, setProgress] = useState<CourseProgressResponse | null>(null);

  useEffect(() => {
    if (!Number.isFinite(courseId)) {
      setStatus('Invalid course selected');
      return;
    }

    courseApi
      .get(courseId)
      .then(setCourse)
      .catch(() => setStatus('Unable to load course'));
  }, [courseApi, courseId]);

  useEffect(() => {
    if (!Number.isFinite(courseId)) {
      return;
    }

    lessonApi
      .list(courseId)
      .then((items) => {
        setLessons(items);
        setSelectedLesson((prev) => prev ?? items[0] ?? null);
        setStatus('');
      })
      .catch(() => setStatus('Unable to load lessons'));
  }, [lessonApi, courseId]);

  useEffect(() => {
    if (!Number.isFinite(courseId)) {
      return;
    }

    courseApi.progress(courseId).then(setProgress).catch(() => {});
  }, [courseApi, courseId, lessons.length]);

  const renderContent = () => {
    if (!selectedLesson) {
      return <p>Select a lesson to continue.</p>;
    }

    if (selectedLesson.lesson_type === 'video' && selectedLesson.content_url) {
      return (
        <div className="lesson-video aspect-video w-full">
          <iframe
            title={selectedLesson.title}
            src={selectedLesson.content_url}
            allowFullScreen
            frameBorder="0"
            className="w-full h-full"
          />
        </div>
      );
    }

    return (
      <>
        {selectedLesson.content_text && (
          <div>
            {selectedLesson.content_text.split('\n').map((line, index) => (
              <p key={index} className="mb-2">{line}</p>
            ))}
          </div>
        )}
        {selectedLesson.content_url && (
          <p className="mt-4">
            Download: <a href={selectedLesson.content_url} className="text-blue-600 hover:underline">open resource</a>
          </p>
        )}
        {!selectedLesson.content_text && !selectedLesson.content_url && <p>No preview available.</p>}
      </>
    );
  };

  return (
    <section className="p-8">
      <header className="mb-6">
        <h1 className="text-4xl font-bold">{course?.title ?? 'Course Player'}</h1>
        <p className="text-lg">
          <Link to={`/courses/${courseId}`} className="text-blue-600 hover:underline">Back to course</Link>
        </p>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-[minmax(200px,280px)_1fr] gap-6">
        <aside className="bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Lessons</h2>
          {status && <p className="text-sm text-gray-700 mb-4">{status}</p>}
          <div className="progress-bar bg-gray-200 rounded-full h-1.5 mb-2 overflow-hidden">
            <div className="progress-bar__fill bg-green-500 h-full transition-all duration-300 ease-in-out" style={{ width: `${progress?.percent ?? 0}%` }} />
          </div>
          <p className="text-sm text-gray-600 mb-4">{progress?.percent ?? 0}% complete</p>
          <ul className="space-y-2">
            {lessons.map((lesson) => (
              <li key={lesson.id}>
                <button
                  type="button"
                  onClick={() => setSelectedLesson(lesson)}
                  className="w-full text-left px-3 py-2 rounded-md border border-gray-300 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center"
                >
                  {progress?.completed_lessons.includes(lesson.id) && <span className="mr-2 text-green-500">✔</span>}
                  {lesson.title}
                </button>
              </li>
            ))}
          </ul>
        </aside>
        <main className="bg-white rounded-lg shadow-md p-6">
          {renderContent()}
          {selectedLesson && (
            <button
              type="button"
              onClick={async () => {
                setStatus('Marking complete...');
                try {
                  await lessonApi.complete(selectedLesson.id);
                  setStatus('Lesson marked complete');
                  const refreshed = await courseApi.progress(courseId);
                  setProgress(refreshed);
                } catch {
                  setStatus('Unable to mark complete');
                }
              }}
              disabled={progress?.completed_lessons.includes(selectedLesson.id)}
              className="mt-6 bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {progress?.completed_lessons.includes(selectedLesson.id) ? 'Completed' : 'Mark complete'}
            </button>
          )}
        </main>
      </div>
    </section>
  );
};

export default CoursePlayer;