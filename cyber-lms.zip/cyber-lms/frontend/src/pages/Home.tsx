const HomePage = () => (
  <section className="p-8">
    <h1 className="text-4xl font-bold mb-4">Cyber LMS</h1>
    <p className="text-lg">Modern training platform templates with Go APIs and React UIs.</p>
  </section>
);

export default HomePage;