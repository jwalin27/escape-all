import { ChangeEvent, FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Lesson, LessonApi, LessonPayload } from '../api/lessons';
import { useAuth } from '../contexts/AuthContext';

type LessonForm = {
  title: string;
  lesson_type: string;
  content_url: string;
  content_text: string;
  order_index: number;
};

const initialForm: LessonForm = {
  title: '',
  lesson_type: 'video',
  content_url: '',
  content_text: '',
  order_index: 1
};

const CourseLessonBuilder = () => {
  const { client } = useAuth();
  const { id } = useParams<{ id: string }>();
  const courseId = Number(id);
  const lessonApi = useMemo(() => new LessonApi(client), [client]);
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [form, setForm] = useState(initialForm);
  const [editing, setEditing] = useState<Lesson | null>(null);
  const [status, setStatus] = useState('');

  const loadLessons = useCallback(() => {
    if (!Number.isFinite(courseId)) {
      return;
    }
    lessonApi.list(courseId).then(setLessons).catch(() => setStatus('Unable to load lessons'));
  }, [courseId, lessonApi]);

  useEffect(() => {
    loadLessons();
  }, [loadLessons]);

  const handleChange = (key: keyof LessonForm) => (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const value =
      key === 'order_index' ? Number(event.target.value) : event.target.value;
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const mapLessonToPayload = (lesson: Lesson): LessonForm => ({
    title: lesson.title,
    lesson_type: lesson.lesson_type,
    content_url: lesson.content_url ?? '',
    content_text: lesson.content_text ?? '',
    order_index: lesson.order_index
  });

  const handleCreate = async (event: FormEvent) => {
    event.preventDefault();
    if (!Number.isFinite(courseId)) {
      return;
    }
    const nextOrder = lessons.length ? Math.max(...lessons.map((item) => item.order_index)) + 1 : 1;
    const payload: LessonPayload = {
      ...form,
      content_url: form.content_url,
      content_text: form.content_text,
      lesson_type: form.lesson_type,
      order_index: nextOrder
    };
    try {
      await lessonApi.create(courseId, payload);
      setForm({ ...initialForm, order_index: nextOrder + 1 });
      loadLessons();
      setStatus('Lesson created');
    } catch {
      setStatus('Unable to create lesson');
    }
  };

  const handleUpdate = async (event: FormEvent) => {
    event.preventDefault();
    if (!editing) {
      return;
    }
    const payload: LessonPayload = {
      ...form,
      content_url: form.content_url,
      content_text: form.content_text,
      lesson_type: form.lesson_type
    };
    try {
      await lessonApi.update(editing.id, payload);
      setEditing(null);
      setForm(initialForm);
      loadLessons();
      setStatus('Lesson saved');
    } catch {
      setStatus('Unable to update lesson');
    }
  };

  const handleEdit = (lesson: Lesson) => {
    setEditing(lesson);
    setForm(mapLessonToPayload(lesson));
  };

  const moveLesson = async (lesson: Lesson, delta: number) => {
    try {
      await lessonApi.update(lesson.id, { ...mapLessonToPayload(lesson), order_index: lesson.order_index + delta });
      loadLessons();
      setStatus('Lesson reordered');
    } catch {
      setStatus('Unable to reorder');
    }
  };

  if (!Number.isFinite(courseId)) {
    return <p className="p-8">Invalid course</p>;
  }

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Lesson builder</h1>
      <p className="text-sm text-gray-700 mb-4">{status}</p>
      <div className="bg-white p-6 shadow rounded-lg mb-8">
        <h2 className="text-2xl font-semibold mb-4">{editing ? 'Editing lesson' : 'New lesson'}</h2>
        <form onSubmit={editing ? handleUpdate : handleCreate} className="space-y-4">
          <label className="block">
            Title
            <input
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={form.title}
              onChange={handleChange('title')}
              required
            />
          </label>
          <label className="block">
            Type
            <select
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={form.lesson_type}
              onChange={handleChange('lesson_type')}
            >
              <option value="video">Video</option>
              <option value="text">Text</option>
            </select>
          </label>
          <label className="block">
            Content URL
            <input
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={form.content_url}
              onChange={handleChange('content_url')}
            />
          </label>
          <label className="block">
            Content text
            <textarea
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={form.content_text}
              onChange={handleChange('content_text')}
            />
          </label>
          <label className="block">
            Order
            <input
              type="number"
              min={1}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
              value={form.order_index}
              onChange={handleChange('order_index')}
            />
          </label>
          <div className="flex space-x-4">
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              {editing ? 'Save lesson' : 'Create lesson'}
            </button>
            {editing && (
              <button
                type="button"
                onClick={() => {
                  setEditing(null);
                  setForm(initialForm);
                }}
                className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>
      <div className="bg-white p-6 shadow rounded-lg">
        <h2 className="text-2xl font-semibold mb-4">Existing lessons</h2>
        <ul className="space-y-4">
          {lessons.map((lesson) => (
            <li key={lesson.id} className="bg-gray-50 p-4 rounded-md shadow-sm flex items-center justify-between">
              <div>
                <strong className="text-lg">{lesson.title}</strong> ({lesson.lesson_type}) &middot; order {lesson.order_index}
              </div>
              <div className="space-x-2">
                <button
                  type="button"
                  onClick={() => handleEdit(lesson)}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-3 rounded text-sm"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => moveLesson(lesson, -1)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-1 px-3 rounded text-sm"
                >
                  Move up
                </button>
                <button
                  type="button"
                  onClick={() => moveLesson(lesson, 1)}
                  className="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-1 px-3 rounded text-sm"
                >
                  Move down
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

export default CourseLessonBuilder;