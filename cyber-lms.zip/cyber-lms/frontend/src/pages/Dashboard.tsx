import { useEffect, useState } from 'react';
import { AuthUser } from '../api/auth';
import { useAuth } from '../contexts/AuthContext';

const DashboardPage = () => {
  const { user, client } = useAuth();
  const [profile, setProfile] = useState<AuthUser | null>(null);
  const [message, setMessage] = useState('Connecting to /me endpoint...');

  useEffect(() => {
    let canceled = false;

    client
      .request<AuthUser>('/auth/me')
      .then((data) => {
        if (!canceled) {
          setProfile(data);
          setMessage('Profile retrieved from /me');
        }
      })
      .catch(() => {
        if (!canceled) {
          setMessage('Unable to reach /me at the moment');
        }
      });

    return () => {
      canceled = true;
    };
  }, [client]);

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Dashboard</h1>
      <p className="mb-2">{message}</p>
      <p>
        Signed in as {user?.email} ({profile?.role ?? user?.role})
      </p>
    </section>
  );
};

export default DashboardPage;