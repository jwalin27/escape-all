import { FormEvent, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CourseApi } from '../api/courses';
import { useAuth } from '../contexts/AuthContext';

const InstructorCourseForm = () => {
  const { client } = useAuth();
  const courseApi = useMemo(() => new CourseApi(client), [client]);
  const navigate = useNavigate();
  const [form, setForm] = useState({ title: '', description: '', published: false });
  const [error, setError] = useState<string | null>(null);

  const handleChange = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const value = key === 'published' ? (event.target as HTMLInputElement).checked : event.target.value;
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);

    try {
      const created = await courseApi.create({
        title: form.title,
        description: form.description,
        published: form.published
      });
      navigate(`/courses/${created.id}`);
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Create Course</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <label className="block">
          Title
          <input
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            value={form.title}
            onChange={handleChange('title')}
            required
          />
        </label>
        <label className="block">
          Description
          <textarea
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
            value={form.description}
            onChange={handleChange('description')}
            required
          />
        </label>
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={form.published}
            onChange={handleChange('published')}
            className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"
          />
          <span>Published</span>
        </label>
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Save course
        </button>
      </form>
    </section>
  );
};

export default InstructorCourseForm;