import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const InstructorDashboard = () => {
  const { client } = useAuth();
  const [message, setMessage] = useState('Loading instructor resources...');

  useEffect(() => {
    let cancelled = false;

    client
      .request<{ message: string }>('/dashboard/instructor')
      .then((data) => {
        if (!cancelled) {
          setMessage(data.message);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setMessage('Unable to load instructor insights.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, [client]);

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">Instructor Dashboard</h1>
      <p className="text-lg">{message}</p>
    </section>
  );
};

export default InstructorDashboard;