import { FormEvent, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { QuizApi } from '../api/quiz';
import { useAuth } from '../contexts/AuthContext';

const QuizPage = () => {
  const { client } = useAuth();
  const params = useParams<{ lessonId: string }>();
  const lessonId = Number(params.lessonId);
  const quizApi = useMemo(() => new QuizApi(client), [client]);
  const [quiz, setQuiz] = useState<{ id: number; lesson_id: number; title: string; questions: { id: number; prompt: string; choices: string[] }[] } | null>(null);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [status, setStatus] = useState('');
  const [result, setResult] = useState<{ score: number; total: number } | null>(null);

  useEffect(() => {
    if (!Number.isFinite(lessonId)) {
      return;
    }
    quizApi
      .fetchLessonQuiz(lessonId)
      .then(setQuiz)
      .catch(() => setStatus('Unable to load quiz'));
  }, [lessonId, quizApi]);

  const handleSelect = (questionId: number, selected: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: selected }));
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    if (!quiz) {
      return;
    }
    const payload = {
      answers: quiz.questions.map((question) => ({
        question_id: question.id,
        selected_index: answers[question.id] ?? -1
      }))
    };

    try {
      const attempt = await quizApi.submitAttempt(quiz.id, payload);
      setResult(attempt);
      setStatus('Quiz submitted');
    } catch {
      setStatus('Unable to submit quiz');
    }
  };

  if (!quiz) {
    return <p className="p-8">{status || 'Loading quiz…'}</p>;
  }

  return (
    <section className="p-8">
      <h1 className="text-4xl font-bold mb-4">{quiz.title}</h1>
      <p className="text-sm text-gray-700 mb-4">{status}</p>
      <form onSubmit={handleSubmit} className="space-y-6">
        {quiz.questions.map((question, index) => (
          <fieldset key={question.id} className="bg-white p-6 shadow rounded-lg">
            <legend className="text-xl font-semibold mb-3">
              {index + 1}. {question.prompt}
            </legend>
            <div className="space-y-2">
              {question.choices.map((choice, idx) => (
                <label key={idx} className="flex items-center space-x-2">
                  <input
                    type="radio"
                    name={`question-${question.id}`}
                    checked={answers[question.id] === idx}
                    onChange={() => handleSelect(question.id, idx)}
                    className="form-radio text-blue-600"
                  />
                  <span>{choice}</span>
                </label>
              ))}
            </div>
          </fieldset>
        ))}
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Submit quiz
        </button>
      </form>
      {result && (
        <div className="mt-8 bg-green-100 border-l-4 border-green-500 text-green-700 p-4 rounded-lg">
          <p className="font-bold">Quiz Result:</p>
          <p>
            Score: {result.score} / {result.total}
          </p>
        </div>
      )}
    </section>
  );
};

export default QuizPage;