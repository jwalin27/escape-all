import { ApiClient } from './client';

export type Course = {
  id: number;
  title: string;
  description: string;
  published: boolean;
  instructor_id: number;
  created_at: string;
  updated_at: string;
};

export type CoursePayload = {
  title: string;
  description: string;
  published: boolean;
};

export type EnrollmentMessage = {
  message?: string;
  status?: string;
};

export type CourseProgressResponse = {
  completed_lessons: number[];
  completed: number;
  total: number;
  percent: number;
};

export class CourseApi {
  constructor(private client: ApiClient) {}

  list(search?: string): Promise<Course[]> {
    const query = search ? `?q=${encodeURIComponent(search)}` : '';
    return this.client.request<Course[]>(`/courses${query}`);
  }

  get(id: number): Promise<Course> {
    return this.client.request<Course>(`/courses/${id}`);
  }

  create(payload: CoursePayload): Promise<Course> {
    return this.client.request<Course>('/courses', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  update(id: number, payload: CoursePayload): Promise<Course> {
    return this.client.request<Course>(`/courses/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  enroll(id: number): Promise<EnrollmentMessage> {
    return this.client.request(`/courses/${id}/enroll`, {
      method: 'POST'
    });
  }

  myEnrollments() {
    return this.client.request<Course[]>('/me/enrollments');
  }

  progress(id: number): Promise<CourseProgressResponse> {
    return this.client.request<CourseProgressResponse>(`/courses/${id}/progress`);
  }
}
