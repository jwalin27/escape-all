export type ApiClientOptions = RequestInit & {
  baseUrl?: string;
};

export type TokenProvider = () => string | null;

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080';

export class ApiClient {
  constructor(private baseUrl: string, private getToken?: TokenProvider) {}

  async request<T>(path: string, options: ApiClientOptions = {}): Promise<T> {
    const url = path.startsWith('http') ? path : `${this.baseUrl}${path}`;
    const headers = new Headers(options.headers);
    headers.set('Content-Type', 'application/json');

    const token = this.getToken?.();
    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }

    const response = await fetch(url, {
      ...options,
      headers
    });

    if (!response.ok) {
      throw new Error('API request failed');
    }

    if (response.status === 204) {
      return {} as T;
    }

    return response.json();
  }
}
