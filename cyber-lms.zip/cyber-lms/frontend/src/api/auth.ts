import { ApiClient } from './client';

export type LoginPayload = {
  email: string;
  password: string;
};

export type RegisterPayload = {
  email: string;
  password: string;
  role: string;
  tenant_name: string;
};

export type AuthUser = {
  id: number;
  email: string;
  role: string;
  tenant_id: string;
};

export type AuthResponse = {
  token: string;
  user: AuthUser;
};

export class AuthApi {
  constructor(private client: ApiClient) {}

  register(payload: RegisterPayload): Promise<AuthResponse> {
    return this.client.request<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  login(payload: LoginPayload): Promise<AuthResponse> {
    return this.client.request<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  logout(): Promise<void> {
    return this.client.request('/auth/logout', {
      method: 'POST'
    });
  }

  me(): Promise<AuthUser> {
    return this.client.request<AuthUser>('/auth/me');
  }
}