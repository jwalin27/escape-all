import { ApiClient } from './client';

export type Lesson = {
  id: number;
  course_id: number;
  title: string;
  lesson_type: string;
  content_url: string | null;
  content_text: string | null;
  order_index: number;
  created_at: string;
  updated_at: string;
};

export type LessonPayload = {
  title: string;
  lesson_type: string;
  content_url: string;
  content_text: string;
  order_index: number;
};

export class LessonApi {
  constructor(private client: ApiClient) {}

  list(courseId: number): Promise<Lesson[]> {
    return this.client.request<Lesson[]>(`/courses/${courseId}/lessons`);
  }

  get(id: number): Promise<Lesson> {
    return this.client.request<Lesson>(`/lessons/${id}`);
  }

  create(courseId: number, payload: LessonPayload): Promise<Lesson> {
    return this.client.request<Lesson>(`/courses/${courseId}/lessons`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  update(id: number, payload: LessonPayload): Promise<Lesson> {
    return this.client.request<Lesson>(`/lessons/${id}`, {
      method: 'PUT',
      body: JSON.stringify(payload)
    });
  }

  complete(id: number) {
    return this.client.request(`/lessons/${id}/complete`, {
      method: 'POST'
    });
  }
}
