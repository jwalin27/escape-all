import { ApiClient } from './client';

export type QuizQuestion = {
  id: number;
  prompt: string;
  choices: string[];
  order_index: number;
};

export type QuizResponse = {
  id: number;
  lesson_id: number;
  title: string;
  created_at: string;
  questions: QuizQuestion[];
};

export type AttemptRequest = {
  answers: {
    question_id: number;
    selected_index: number;
  }[];
};

export type AttemptResult = {
  score: number;
  total: number;
};

export type InstructorReportResponse = {
  enrolled: number;
  completion_pct: number;
  average_score: number;
  total_lessons: number;
  completed_entries: number;
};

export class QuizApi {
  constructor(private client: ApiClient) {}

  fetchLessonQuiz(lessonId: number): Promise<QuizResponse> {
    return this.client.request<QuizResponse>(`/lessons/${lessonId}/quiz`);
  }

  submitAttempt(quizId: number, payload: AttemptRequest): Promise<AttemptResult> {
    return this.client.request<AttemptResult>(`/quizzes/${quizId}/attempts`, {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }

  report(courseId: number): Promise<InstructorReportResponse> {
    return this.client.request<InstructorReportResponse>(`/instructor/courses/${courseId}/report`);
  }
}
