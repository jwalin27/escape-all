import { ReactNode, useEffect, useMemo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

type Props = {
  children: ReactNode;
};

const AppLayout = ({ children }: Props) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const handleSignOut = async () => {
    await logout();
    navigate('/login');
  };

  const normalizedRole = user?.role?.toLowerCase();
  const isInstructor = normalizedRole === 'instructor' || normalizedRole === 'admin';

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const NavButton = ({ to, children }: { to: string; children: ReactNode }) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `keycap-button whitespace-nowrap ${isActive ? 'opacity-100' : 'opacity-90 hover:opacity-100'}`
      }
    >
      {children}
    </NavLink>
  );

  const centerLinks = useMemo(() => {
    const links: Array<{ label: string; to: string; isVisible?: boolean }> = [
      { label: 'Home', to: '/' },
      { label: 'Courses', to: '/courses' },
      { label: 'My Courses', to: '/my-courses', isVisible: !!user },
      { label: 'Dashboard', to: '/dashboard', isVisible: !!user },
      { label: 'New Course', to: '/courses/new', isVisible: isInstructor },
      { label: 'Learner View', to: '/dashboard/learner', isVisible: !!user },
      { label: 'Instructor View', to: '/dashboard/instructor', isVisible: isInstructor },
    ];

    return links.filter((link) => link.isVisible ?? true);
  }, [isInstructor, user]);

  return (
    <div className="min-h-screen flex flex-col bg-body-bg-light text-body-color-light">
      <nav className="w-full bg-[#ece7dd] px-4 py-3 border-b border-[#cdb79f]">
        <div className="mx-auto max-w-7xl flex items-center gap-3">
          <NavLink to="/" className="keycap-button font-normal">
            Cyber LMS
          </NavLink>

          <div className="hidden md:flex flex-1 items-center justify-center gap-3">
            {centerLinks.map((link) => (
              <NavButton key={link.to} to={link.to}>
                {link.label}
              </NavButton>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3 justify-end">
            {user ? (
              <>
                <span className="text-sm text-[#3a2416]">{user.email}</span>
                <button type="button" onClick={handleSignOut} className="keycap-button">
                  Sign out
                </button>
              </>
            ) : (
              <>
                <NavButton to="/login">Sign in</NavButton>
                <NavButton to="/register">Register</NavButton>
              </>
            )}
          </div>

          <div className="md:hidden ml-auto">
            <button
              type="button"
              className="keycap-button"
              onClick={() => setMenuOpen((value) => !value)}
              aria-label="Toggle menu"
              aria-expanded={menuOpen}
            >
              ☰
            </button>
          </div>
        </div>

        {menuOpen && (
          <div className="md:hidden mt-3 px-4 flex flex-col gap-3">
            {centerLinks.map((link) => (
              <NavButton key={link.to} to={link.to}>
                {link.label}
              </NavButton>
            ))}

            {user ? (
              <button type="button" onClick={handleSignOut} className="keycap-button">
                Sign out
              </button>
            ) : (
              <>
                <NavButton to="/login">Sign in</NavButton>
                <NavButton to="/register">Register</NavButton>
              </>
            )}
          </div>
        )}
      </nav>
      <main className="p-8 flex-1">{children}</main>
    </div>
  );
};

export default AppLayout;
