package course

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"time"

	"github.com/google/uuid"
)

// Course represents instructor-provided content.
type Course struct {
	ID           int64
	Title        string
	Description  string
	Published    bool
	InstructorID int64
	TenantID     uuid.UUID // Add TenantID field
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

type Store struct {
	db *sql.DB
}

// NewStore returns a course store backed by the provided database.
func NewStore(db *sql.DB) *Store {
	return &Store{db: db}
}

// Create adds a new course record authored by the instructor.
func (s *Store) Create(ctx context.Context, title, description string, published bool, instructorID int64, tenantID uuid.UUID) (*Course, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		INSERT INTO courses (title, description, published, instructor_id, tenant_id, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		RETURNING id, title, description, published, instructor_id, tenant_id, created_at, updated_at
	`, title, description, published, instructorID, tenantID, now, now)

	var c Course
	if err := row.Scan(&c.ID, &c.Title, &c.Description, &c.Published, &c.InstructorID, &c.TenantID, &c.CreatedAt, &c.UpdatedAt); err != nil {
		return nil, err
	}

	return &c, nil
}

// Update modifies a course owned by the instructor.
func (s *Store) Update(ctx context.Context, id, instructorID int64, title, description string, published bool, tenantID uuid.UUID) (*Course, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		UPDATE courses
		SET title = $1, description = $2, published = $3, updated_at = $4
		WHERE id = $5 AND instructor_id = $6 AND tenant_id = $7
		RETURNING id, title, description, published, instructor_id, tenant_id, created_at, updated_at
	`, title, description, published, now, id, instructorID, tenantID)

	var c Course
	if err := row.Scan(&c.ID, &c.Title, &c.Description, &c.Published, &c.InstructorID, &c.TenantID, &c.CreatedAt, &c.UpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &c, nil
}

// GetByID returns a course even if unpublished.
func (s *Store) GetByID(ctx context.Context, id int64, tenantID uuid.UUID) (*Course, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, title, description, published, instructor_id, tenant_id, created_at, updated_at
		FROM courses
		WHERE id = $1 AND tenant_id = $2
	`, id, tenantID)

	var c Course
	if err := row.Scan(&c.ID, &c.Title, &c.Description, &c.Published, &c.InstructorID, &c.TenantID, &c.CreatedAt, &c.UpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &c, nil
}

// List returns published courses, with an optional title description filter.
func (s *Store) List(ctx context.Context, tenantID uuid.UUID, search string) ([]Course, error) {
	query := `
		SELECT id, title, description, published, instructor_id, tenant_id, created_at, updated_at
		FROM courses
		WHERE published = TRUE AND tenant_id = $1
	`
	args := []any{tenantID}
	if trimmed := strings.TrimSpace(search); trimmed != "" {
		query += " AND (title ILIKE $2 OR description ILIKE $2)"
		args = append(args, "%"+trimmed+"%")
	}
	query += " ORDER BY created_at DESC"

	rows, err := s.db.QueryContext(ctx, query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var courses []Course
	for rows.Next() {
		var c Course
		if err := rows.Scan(&c.ID, &c.Title, &c.Description, &c.Published, &c.InstructorID, &c.TenantID, &c.CreatedAt, &c.UpdatedAt); err != nil {
			return nil, err
		}
		courses = append(courses, c)
	}
	return courses, rows.Err()
}

// Enrollment represents a learner signed up for a course.
type Enrollment struct {
	ID         int64
	UserID     int64
	CourseID   int64
	TenantID   uuid.UUID
	EnrolledAt time.Time
}

// Enroll registers a user for a course, ignoring duplicates.
func (s *Store) Enroll(ctx context.Context, userID, courseID int64, tenantID uuid.UUID) (*Enrollment, error) {
	row := s.db.QueryRowContext(ctx, `
		INSERT INTO enrollments (user_id, course_id, tenant_id)
		VALUES ($1, $2, $3)
		ON CONFLICT (user_id, course_id) DO NOTHING
		RETURNING id, user_id, course_id, enrolled_at, tenant_id
	`, userID, courseID, tenantID)

	var e Enrollment
	if err := row.Scan(&e.ID, &e.UserID, &e.CourseID, &e.EnrolledAt, &e.TenantID); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}

	return &e, nil
}

// ListEnrollments returns courses a user is enrolled in.
func (s *Store) ListEnrollments(ctx context.Context, userID int64, tenantID uuid.UUID) ([]Course, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT c.id, c.title, c.description, c.published, c.instructor_id, c.tenant_id, c.created_at, c.updated_at
		FROM courses c
		JOIN enrollments e ON e.course_id = c.id
		WHERE e.user_id = $1 AND e.tenant_id = $2
		ORDER BY e.enrolled_at DESC
	`, userID, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var courses []Course
	for rows.Next() {
		var c Course
		if err := rows.Scan(&c.ID, &c.Title, &c.Description, &c.Published, &c.InstructorID, &c.TenantID, &c.CreatedAt, &c.UpdatedAt); err != nil {
			return nil, err
		}
		courses = append(courses, c)
	}

	return courses, rows.Err()
}

// IsEnrolled returns true when a user is already enrolled in a course.
func (s *Store) IsEnrolled(ctx context.Context, userID, courseID int64, tenantID uuid.UUID) (bool, error) {
	var enrolled bool
	err := s.db.QueryRowContext(ctx, `
		SELECT EXISTS(
			SELECT 1 FROM enrollments WHERE user_id = $1 AND course_id = $2 AND tenant_id = $3
		)
	`, userID, courseID, tenantID).Scan(&enrolled)
	if err != nil {
		return false, err
	}
	return enrolled, nil
}

// ErrNotFound signals the referenced course was missing.
var ErrNotFound = errors.New("course not found")
