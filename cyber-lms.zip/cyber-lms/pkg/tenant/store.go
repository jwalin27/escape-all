package tenant

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/google/uuid"
)

// Tenant represents an organization.
type Tenant struct {
	ID        uuid.UUID
	Name      string
	CreatedAt time.Time
	UpdatedAt time.Time
}

// Store encapsulates queries related to tenants.
type Store struct {
	db *sql.DB
}

// NewStore returns a tenant store backed by the provided database.
func NewStore(db *sql.DB) *Store {
	return &Store{db: db}
}

// Create inserts a new tenant with the supplied name.
func (s *Store) Create(ctx context.Context, name string) (*Tenant, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		INSERT INTO tenants (name, created_at, updated_at)
		VALUES ($1, $2, $3)
		RETURNING id, name, created_at, updated_at
	`, name, now, now)

	var t Tenant
	if err := row.Scan(&t.ID, &t.Name, &t.CreatedAt, &t.UpdatedAt); err != nil {
		return nil, err
	}

	return &t, nil
}

// GetByID retrieves a tenant by its ID.
func (s *Store) GetByID(ctx context.Context, id uuid.UUID) (*Tenant, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, name, created_at, updated_at
		FROM tenants
		WHERE id = $1
	`, id)

	var t Tenant
	if err := row.Scan(&t.ID, &t.Name, &t.CreatedAt, &t.UpdatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &t, nil
}

// ErrNotFound indicates the tenant was not located.
var ErrNotFound = errors.New("tenant not found")
