package quiz

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/google/uuid"
	"github.com/lib/pq"
)

type Quiz struct {
	ID        int64
	LessonID  int64
	Title     string
	TenantID  uuid.UUID
	CreatedAt time.Time
	Questions []Question
}

type Question struct {
	ID           int64
	QuizID       int64
	Prompt       string
	Choices      []string
	CorrectIndex int
	OrderIndex   int
}

type Attempt struct {
	ID        int64
	QuizID    int64
	UserID    int64
	TenantID  uuid.UUID
	Score     int
	CreatedAt time.Time
	Answers   []Answer
}

type Answer struct {
	AttemptID     int64
	QuestionID    int64
	SelectedIndex int
}

type Store struct {
	db *sql.DB
}

func NewStore(db *sql.DB) *Store {
	return &Store{db: db}
}

func (s *Store) CreateQuiz(ctx context.Context, lessonID int64, title string, questions []Question, tenantID uuid.UUID) (*Quiz, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	var quizID int64
	var createdAt time.Time
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO quizzes (lesson_id, title, tenant_id, created_at)
		VALUES ($1, $2, $3, $4)
		RETURNING id, created_at
	`, lessonID, title, tenantID, time.Now().UTC()).Scan(&quizID, &createdAt); err != nil {
		return nil, err
	}

	insertQuestion := `
		INSERT INTO quiz_questions (quiz_id, prompt, choices, correct_index, order_index)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id
	`
	for idx, q := range questions {
		var questionID int64
		if err := tx.QueryRowContext(ctx, insertQuestion, quizID, q.Prompt, pq.Array(q.Choices), q.CorrectIndex, q.OrderIndex+idx).Scan(&questionID); err != nil {
			return nil, err
		}
		q.ID = questionID
		q.QuizID = quizID
		questions[idx] = q
	}

	if err := tx.Commit(); err != nil {
		return nil, err
	}

	return &Quiz{
		ID:        quizID,
		LessonID:  lessonID,
		Title:     title,
		TenantID:  tenantID,
		CreatedAt: createdAt,
		Questions: questions,
	}, nil
}

func (s *Store) GetQuizByLesson(ctx context.Context, lessonID int64, tenantID uuid.UUID) (*Quiz, error) {
	var quiz Quiz
	if err := s.db.QueryRowContext(ctx, `
		SELECT id, title, created_at
		FROM quizzes
		WHERE lesson_id = $1 AND tenant_id = $2
	`, lessonID, tenantID).Scan(&quiz.ID, &quiz.Title, &quiz.CreatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, nil
		}
		return nil, err
	}

	rows, err := s.db.QueryContext(ctx, `
		SELECT id, prompt, choices, correct_index, order_index
		FROM quiz_questions
		WHERE quiz_id = $1
		ORDER BY order_index ASC
	`, quiz.ID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var q Question
		var choices pq.StringArray
		if err := rows.Scan(&q.ID, &q.Prompt, &choices, &q.CorrectIndex, &q.OrderIndex); err != nil {
			return nil, err
		}
		q.Choices = []string(choices)
		q.QuizID = quiz.ID
		quiz.Questions = append(quiz.Questions, q)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	return &quiz, nil
}

func (s *Store) SubmitAttempt(ctx context.Context, quizID, userID int64, answers []Answer, tenantID uuid.UUID) (*Attempt, error) {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()

	rows, err := tx.QueryContext(ctx, `
		SELECT id, correct_index
		FROM quiz_questions qq
		JOIN quizzes q ON q.id = qq.quiz_id
		WHERE qq.quiz_id = $1 AND q.tenant_id = $2
	`, quizID, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	correctMap := map[int64]int{}
	for rows.Next() {
		var id int64
		var correctIndex int
		if err := rows.Scan(&id, &correctIndex); err != nil {
			return nil, err
		}
		correctMap[id] = correctIndex
	}

	score := 0
	for _, answer := range answers {
		if correctMap[answer.QuestionID] == answer.SelectedIndex {
			score++
		}
	}

	var attemptID int64
	var attemptCreatedAt time.Time
	if err := tx.QueryRowContext(ctx, `
		INSERT INTO quiz_attempts (quiz_id, user_id, tenant_id, score, created_at)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, created_at
	`, quizID, userID, tenantID, score, time.Now().UTC()).Scan(&attemptID, &attemptCreatedAt); err != nil {
		return nil, err
	}

	answerStmt, err := tx.PrepareContext(ctx, `
		INSERT INTO quiz_answers (attempt_id, question_id, selected_index)
		VALUES ($1, $2, $3)
	`)
	if err != nil {
		return nil, err
	}
	defer answerStmt.Close()

	for _, answer := range answers {
		if _, err := answerStmt.ExecContext(ctx, attemptID, answer.QuestionID, answer.SelectedIndex); err != nil {
			return nil, err
		}
	}

	if err := tx.Commit(); err != nil {
		return nil, err
	}

	return &Attempt{
		ID:        attemptID,
		QuizID:    quizID,
		UserID:    userID,
		TenantID:  tenantID,
		Score:     score,
		CreatedAt: attemptCreatedAt,
		Answers:   answers,
	}, nil
}

func (s *Store) InstructorReport(ctx context.Context, courseID int64, tenantID uuid.UUID) (int, int, error) {
	var totalUsers int
	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(DISTINCT user_id)
		FROM enrollments
		WHERE course_id = $1 AND tenant_id = $2
	`, courseID, tenantID).Scan(&totalUsers); err != nil {
		return 0, 0, err
	}

	var avgScore int
	if err := s.db.QueryRowContext(ctx, `
		SELECT COALESCE(AVG(score), 0)
		FROM quiz_attempts a
		JOIN quizzes q ON q.id = a.quiz_id
		JOIN lessons l ON l.id = q.lesson_id
		WHERE l.course_id = $1 AND l.tenant_id = $2
	`, courseID, tenantID).Scan(&avgScore); err != nil {
		return 0, 0, err
	}

	return totalUsers, avgScore, nil
}
