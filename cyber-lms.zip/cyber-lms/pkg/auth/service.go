package auth

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid" // Import uuid
	"github.com/lib/pq"
	"golang.org/x/crypto/bcrypt"

	"github.com/escape-all/cyber-lms/internal/config"
	"github.com/escape-all/cyber-lms/pkg/user"
)

var (
	// ErrInvalidCredentials is returned when supplied auth data does not match.
	ErrInvalidCredentials = errors.New("invalid credentials")
	// ErrDuplicateUser signals the email is already registered.
	ErrDuplicateUser = errors.New("user already exists")
)

var builderRoles = map[string]struct{}{
	"instructor": {},
	"learner":    {},
	"admin":      {},
}

// AuthUser represents the subset of user data safe to return to clients.
type AuthUser struct {
	ID       int64     `json:"id"`
	Email    string    `json:"email"`
	Role     string    `json:"role"`
	TenantID uuid.UUID `json:"tenant_id"` // Add TenantID
}

// AuthResponse is the payload returned after registration/login.
type AuthResponse struct {
	Token string   `json:"token"`
	User  AuthUser `json:"user"`
}

// Service handles registration, login, and token validation.
type Service struct {
	store     *user.Store
	jwtSecret string
	tokenTTL  time.Duration
}

// NewService configures the auth service using the given dependencies.
func NewService(store *user.Store, cfg *config.Config) *Service {
	ttl := cfg.Auth.TokenTTL
	if ttl <= 0 {
		ttl = 24 * time.Hour
	}

	return &Service{
		store:     store,
		jwtSecret: cfg.Auth.JWTSecret,
		tokenTTL:  ttl,
	}
}

// Register creates a new user and issues a JWT.
func (s *Service) Register(ctx context.Context, email, password, role string, tenantID uuid.UUID) (*AuthResponse, error) { // Add tenantID
	role = strings.ToLower(strings.TrimSpace(role))
	if role == "" {
		role = "learner"
	}
	if _, ok := builderRoles[role]; !ok {
		return nil, fmt.Errorf("unsupported role %q", role)
	}

	if strings.TrimSpace(email) == "" || password == "" {
		return nil, ErrInvalidCredentials
	}

	hashed, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, fmt.Errorf("hash password: %w", err)
	}

	u, err := s.store.Create(ctx, email, string(hashed), role, tenantID) // Pass tenantID
	if err != nil {
		var pqErr *pq.Error
		if errors.As(err, &pqErr) && pqErr.Code.Name() == "unique_violation" {
			return nil, ErrDuplicateUser
		}
		return nil, fmt.Errorf("create user: %w", err)
	}

	return s.generateResponse(u)
}

// Login validates credentials and returns an auth response.
func (s *Service) Login(ctx context.Context, email, password string) (*AuthResponse, error) {
	u, err := s.store.GetByEmail(ctx, email)
	if err != nil {
		if errors.Is(err, user.ErrNotFound) {
			return nil, ErrInvalidCredentials
		}
		return nil, fmt.Errorf("lookup user: %w", err)
	}

	if err := bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(password)); err != nil {
		return nil, ErrInvalidCredentials
	}

	return s.generateResponse(u)
}

// Authenticate validates a JWT and returns the associated user.
func (s *Service) Authenticate(ctx context.Context, token string) (*user.User, error) {
	claims := &authClaims{}
	parsed, err := jwt.ParseWithClaims(token, claims, func(tok *jwt.Token) (any, error) {
		if tok.Method.Alg() != jwt.SigningMethodHS256.Alg() {
			return nil, fmt.Errorf("unexpected signing method: %s", tok.Method.Alg())
		}
		if s.jwtSecret == "" {
			return nil, errors.New("jwt secret not configured")
		}

		return []byte(s.jwtSecret), nil
	})
	if err != nil {
		return nil, err
	}
	if !parsed.Valid {
		return nil, errors.New("invalid token")
	}

	return s.store.GetByID(ctx, claims.UserID, claims.TenantID)
}

func (s *Service) generateResponse(u *user.User) (*AuthResponse, error) {
	token, err := s.generateToken(u)
	if err != nil {
		return nil, fmt.Errorf("generate token: %w", err)
	}

	return &AuthResponse{
		Token: token,
		User:  mapUser(u),
	}, nil
}

func (s *Service) generateToken(u *user.User) (string, error) {
	if s.jwtSecret == "" {
		return "", errors.New("jwt secret not configured")
	}

	claims := authClaims{
		UserID:   u.ID,
		Role:     u.Role,
		TenantID: u.TenantID, // Add TenantID to claims
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(s.tokenTTL)),
			Subject:   fmt.Sprintf("%d", u.ID),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(s.jwtSecret))
}

func mapUser(u *user.User) AuthUser {
	return AuthUser{
		ID:       u.ID,
		Email:    u.Email,
		Role:     u.Role,
		TenantID: u.TenantID, // Map TenantID
	}
}

type authClaims struct {
	UserID   int64     `json:"user_id"`
	Role     string    `json:"role"`
	TenantID uuid.UUID `json:"tenant_id"` // Add TenantID
	jwt.RegisteredClaims
}
