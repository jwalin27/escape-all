package progress

import (
	"context"
	"database/sql"
	"time"

	"github.com/google/uuid"
)

// ProgressStore handles lesson progress recording and queries.
type ProgressStore struct {
	db *sql.DB
}

// NewStore returns a store backed by the provided database.
func NewStore(db *sql.DB) *ProgressStore {
	return &ProgressStore{db: db}
}

// MarkComplete records a completed lesson for a user.
func (s *ProgressStore) MarkComplete(ctx context.Context, userID, lessonID int64, tenantID uuid.UUID) error {
	_, err := s.db.ExecContext(ctx, `
		INSERT INTO lesson_progress (user_id, lesson_id, tenant_id, completed_at)
		VALUES ($1, $2, $3, $4)
		ON CONFLICT (user_id, lesson_id, tenant_id) DO UPDATE
		SET completed_at = EXCLUDED.completed_at
	`, userID, lessonID, tenantID, time.Now().UTC())
	return err
}

// CompletedLessons returns a set of lesson IDs the user completed in the given course.
func (s *ProgressStore) CompletedLessons(ctx context.Context, userID, courseID int64, tenantID uuid.UUID) (map[int64]time.Time, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT p.lesson_id, p.completed_at
		FROM lesson_progress p
		JOIN lessons l ON l.id = p.lesson_id
		WHERE p.user_id = $1 AND l.course_id = $2 AND p.tenant_id = $3
	`, userID, courseID, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	result := make(map[int64]time.Time)
	for rows.Next() {
		var lessonID int64
		var completedAt time.Time
		if err := rows.Scan(&lessonID, &completedAt); err != nil {
			return nil, err
		}
		result[lessonID] = completedAt
	}
	return result, rows.Err()
}

// CourseProgress aggregates completion counts for the current user.
func (s *ProgressStore) CourseProgress(ctx context.Context, userID, courseID int64, tenantID uuid.UUID) (completed int, total int, err error) {
	err = s.db.QueryRowContext(ctx, `
		SELECT COUNT(p.lesson_id), (
			SELECT COUNT(1) FROM lessons WHERE course_id = $2 AND tenant_id = $3
		)
		FROM lesson_progress p
		JOIN lessons l ON l.id = p.lesson_id
		WHERE p.user_id = $1 AND l.course_id = $2 AND p.tenant_id = $3
	`, userID, courseID, tenantID).Scan(&completed, &total)
	return
}

// InstructorProgress reports aggregates for instructors/admins per course.
func (s *ProgressStore) InstructorProgress(ctx context.Context, courseID int64, tenantID uuid.UUID) (int, int, error) {
	var totalUsers int
	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(DISTINCT user_id)
		FROM enrollments
		WHERE course_id = $1 AND tenant_id = $2
	`, courseID, tenantID).Scan(&totalUsers); err != nil {
		return 0, 0, err
	}

	var completedCounts int
	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(p.lesson_id)
		FROM lesson_progress p
		JOIN lessons l ON l.id = p.lesson_id
		WHERE l.course_id = $1 AND p.tenant_id = $2
	`, courseID, tenantID).Scan(&completedCounts); err != nil {
		return 0, 0, err
	}

	return completedCounts, totalUsers, nil
}

func (s *ProgressStore) CourseCompletionStats(ctx context.Context, courseID int64, tenantID uuid.UUID) (completedEntries, totalLessons, totalUsers int, err error) {
	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(DISTINCT user_id)
		FROM enrollments
		WHERE course_id = $1 AND tenant_id = $2
	`, courseID, tenantID).Scan(&totalUsers); err != nil {
		return 0, 0, 0, err
	}

	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(1)
		FROM lessons
		WHERE course_id = $1 AND tenant_id = $2
	`, courseID, tenantID).Scan(&totalLessons); err != nil {
		return 0, 0, 0, err
	}

	completedEntries = 0
	if err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(1)
		FROM lesson_progress p
		JOIN lessons l ON l.id = p.lesson_id
		WHERE l.course_id = $1 AND p.tenant_id = $2
	`, courseID, tenantID).Scan(&completedEntries); err != nil {
		return 0, 0, 0, err
	}

	return completedEntries, totalLessons, totalUsers, nil
}
