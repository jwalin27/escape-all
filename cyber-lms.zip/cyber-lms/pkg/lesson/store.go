package lesson

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/google/uuid" // Import uuid
)

// Lesson captures the metadata/sourcing for course content.
type Lesson struct {
	ID          int64
	CourseID    int64
	Title       string
	LessonType  string
	ContentURL  string
	ContentText string
	OrderIndex  int
	TenantID    uuid.UUID // Add TenantID field
	CreatedAt   time.Time
	UpdatedAt   time.Time
}

// Store handles persistence for lessons.
type Store struct {
	db *sql.DB
}

// NewStore wires lessons around the given database.
func NewStore(db *sql.DB) *Store {
	return &Store{db: db}
}

// Create inserts a lesson tied to a course.
func (s *Store) Create(ctx context.Context, courseID int64, title, lessonType, contentURL, contentText string, orderIndex int, tenantID uuid.UUID) (*Lesson, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		INSERT INTO lessons (course_id, title, lesson_type, content_url, content_text, order_index, tenant_id, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
		RETURNING id, course_id, title, lesson_type, content_url, content_text, order_index, tenant_id, created_at, updated_at
	`, courseID, title, lessonType, nullString(contentURL), nullString(contentText), orderIndex, tenantID, now, now)

	return scanLesson(row)
}

// Update applies changes to an existing lesson.
func (s *Store) Update(ctx context.Context, id int64, title, lessonType, contentURL, contentText string, orderIndex int, tenantID uuid.UUID) (*Lesson, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		UPDATE lessons
		SET title = $1, lesson_type = $2, content_url = $3, content_text = $4, order_index = $5, updated_at = $6
		WHERE id = $7 AND tenant_id = $8
		RETURNING id, course_id, title, lesson_type, content_url, content_text, order_index, tenant_id, created_at, updated_at
	`, title, lessonType, nullString(contentURL), nullString(contentText), orderIndex, now, id, tenantID)

	return scanLesson(row)
}

// GetByID fetches a lesson by its identifier.
func (s *Store) GetByID(ctx context.Context, id int64, tenantID uuid.UUID) (*Lesson, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, course_id, title, lesson_type, content_url, content_text, order_index, tenant_id, created_at, updated_at
		FROM lessons
		WHERE id = $1 AND tenant_id = $2
	`, id, tenantID)

	return scanLesson(row)
}

// ListByCourse returns all lessons for the given course ordered by order_index.
func (s *Store) ListByCourse(ctx context.Context, courseID int64, tenantID uuid.UUID) ([]Lesson, error) {
	rows, err := s.db.QueryContext(ctx, `
		SELECT id, course_id, title, lesson_type, content_url, content_text, order_index, tenant_id, created_at, updated_at
		FROM lessons
		WHERE course_id = $1 AND tenant_id = $2
		ORDER BY order_index ASC, created_at ASC
	`, courseID, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var lessons []Lesson
	for rows.Next() {
		var l Lesson
		if err := scanLessonRow(rows, &l); err != nil {
			return nil, err
		}
		lessons = append(lessons, l)
	}
	return lessons, rows.Err()
}

// CountByCourse returns how many lessons exist for a given course.
func (s *Store) CountByCourse(ctx context.Context, courseID int64, tenantID uuid.UUID) (int, error) {
	var total int
	err := s.db.QueryRowContext(ctx, `
		SELECT COUNT(1)
		FROM lessons
		WHERE course_id = $1 AND tenant_id = $2
	`, courseID, tenantID).Scan(&total)
	return total, err
}

var ErrNotFound = errors.New("lesson not found")

func scanLesson(row *sql.Row) (*Lesson, error) {
	var l Lesson
	if err := scanLessonRow(row, &l); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}
	return &l, nil
}

func scanLessonRow(scanner interface {
	Scan(dest ...any) error
}, l *Lesson) error {
	var url sql.NullString
	var text sql.NullString
	// Update scan arguments to include TenantID
	if err := scanner.Scan(&l.ID, &l.CourseID, &l.Title, &l.LessonType, &url, &text, &l.OrderIndex, &l.TenantID, &l.CreatedAt, &l.UpdatedAt); err != nil {
		return err
	}
	if url.Valid {
		l.ContentURL = url.String
	}
	if text.Valid {
		l.ContentText = text.String
	}
	return nil
}

func nullString(value string) sql.NullString {
	return sql.NullString{String: value, Valid: value != ""}
}
