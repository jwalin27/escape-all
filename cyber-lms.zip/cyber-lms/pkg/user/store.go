package user

import (
	"context"
	"database/sql"
	"errors"
	"time"

	"github.com/google/uuid"
)

// User represents a persisted account with a role assignment.
type User struct {
	ID           int64
	Email        string
	PasswordHash string
	Role         string
	TenantID     uuid.UUID
	CreatedAt    time.Time
}

// Store encapsulates queries related to users.
type Store struct {
	db *sql.DB
}

// NewStore returns a user store backed by the provided database.
func NewStore(db *sql.DB) *Store {
	return &Store{db: db}
}

// Create inserts a new user with the supplied hashed password and role.
func (s *Store) Create(ctx context.Context, email, passwordHash, role string, tenantID uuid.UUID) (*User, error) {
	now := time.Now().UTC()
	row := s.db.QueryRowContext(ctx, `
		INSERT INTO users (email, password_hash, role, tenant_id, created_at)
		VALUES ($1, $2, $3, $4, $5)
		RETURNING id, email, password_hash, role, tenant_id, created_at
	`, email, passwordHash, role, tenantID, now)

	var u User
	if err := row.Scan(&u.ID, &u.Email, &u.PasswordHash, &u.Role, &u.TenantID, &u.CreatedAt); err != nil {
		return nil, err
	}

	return &u, nil
}

// GetByEmail retrieves a user by their email address.
func (s *Store) GetByEmail(ctx context.Context, email string) (*User, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, email, password_hash, role, tenant_id, created_at
		FROM users
		WHERE email = $1
	`, email)

	var u User
	if err := row.Scan(&u.ID, &u.Email, &u.PasswordHash, &u.Role, &u.TenantID, &u.CreatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &u, nil
}

// GetByID retrieves a user by their numeric ID and tenant ID.
func (s *Store) GetByID(ctx context.Context, id int64, tenantID uuid.UUID) (*User, error) {
	row := s.db.QueryRowContext(ctx, `
		SELECT id, email, password_hash, role, tenant_id, created_at
		FROM users
		WHERE id = $1 AND tenant_id = $2
	`, id, tenantID)

	var u User
	if err := row.Scan(&u.ID, &u.Email, &u.PasswordHash, &u.Role, &u.TenantID, &u.CreatedAt); err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return nil, ErrNotFound
		}
		return nil, err
	}

	return &u, nil
}

// ErrNotFound indicates the user was not located.
var ErrNotFound = errors.New("user not found")
