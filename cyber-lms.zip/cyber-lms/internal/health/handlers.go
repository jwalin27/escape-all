package health

import (
	"database/sql"
	"encoding/json"
	"net/http"
)

type statusResponse struct {
	Status string `json:"status"`
}

// Handle returns a lightweight heartbeat for load balancers.
func Handle(w http.ResponseWriter, r *http.Request) {
	respondJSON(w, statusResponse{Status: "ok"})
}

// Ready verifies database connectivity before declaring the service operational.
func Ready(db *sql.DB) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if err := db.PingContext(r.Context()); err != nil {
			http.Error(w, "database unavailable", http.StatusServiceUnavailable)
			return
		}
		respondJSON(w, statusResponse{Status: "ready"})
	}
}

func respondJSON(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(v)
}
