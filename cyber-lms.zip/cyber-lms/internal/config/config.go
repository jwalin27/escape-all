package config

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"github.com/spf13/viper"
)

// Config holds application-wide settings sourced from config files and environment variables.
type Config struct {
	Server struct {
		Address string `mapstructure:"address"`
	} `mapstructure:"server"`
	Database struct {
		URL string `mapstructure:"url"`
	} `mapstructure:"database"`
	Migrations struct {
		Dir string `mapstructure:"dir"`
	} `mapstructure:"migrations"`
	Auth struct {
		JWTSecret string        `mapstructure:"jwt_secret"`
		TokenTTL  time.Duration `mapstructure:"token_ttl"`
	} `mapstructure:"auth"`
	LogLevel string `mapstructure:"loglevel"`
}

// LoadConfig resolves configuration from optional files and environment variables.
func LoadConfig() (*Config, error) {
	v := viper.New()
	v.SetConfigName("config")
	v.SetConfigType("yaml")
	v.AddConfigPath(".")
	v.AddConfigPath("configs")
	v.SetEnvPrefix("CYBER_LMS")
	v.AutomaticEnv()
	v.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))

	v.SetDefault("server.address", ":8080")
	v.SetDefault("database.url", "postgres://postgres:postgres@127.0.0.1:5432/cyber_lms?sslmode=disable")
	v.SetDefault("migrations.dir", "migrations")
	v.SetDefault("loglevel", "info")
	v.SetDefault("auth.jwt_secret", "change-me")
	v.SetDefault("auth.token_ttl", "24h")

	if envPath := os.Getenv("CONFIG_PATH"); envPath != "" {
		v.SetConfigFile(envPath)
	}

	if err := v.ReadInConfig(); err != nil {
		var notFound viper.ConfigFileNotFoundError
		if !errors.As(err, &notFound) {
			return nil, fmt.Errorf("read config: %w", err)
		}
	}

	var cfg Config
	if err := v.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("unmarshal config: %w", err)
	}

	return &cfg, nil
}
