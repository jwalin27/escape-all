package middleware

import (
	"context"
	"net/http"
	"strings"

	"github.com/escape-all/cyber-lms/pkg/auth"
	"github.com/escape-all/cyber-lms/pkg/user"
)

type contextKey string

const userContextKey contextKey = "auth_user"

// Auth verifies the Authorization header and injects a user into the request context.
func Auth(s *auth.Service) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			header := r.Header.Get("Authorization")
			if header == "" {
				http.Error(w, "authorization required", http.StatusUnauthorized)
				return
			}

			parts := strings.SplitN(header, " ", 2)
			if len(parts) != 2 || !strings.EqualFold(parts[0], "Bearer") {
				http.Error(w, "invalid authorization format", http.StatusUnauthorized)
				return
			}

			token := strings.TrimSpace(parts[1])
			u, err := s.Authenticate(r.Context(), token)
			if err != nil {
				http.Error(w, "invalid token", http.StatusUnauthorized)
				return
			}

			next.ServeHTTP(w, r.WithContext(WithUser(r.Context(), u)))
		})
	}
}

// WithUser adds a user to the provided context.
func WithUser(ctx context.Context, u *user.User) context.Context {
	return context.WithValue(ctx, userContextKey, u)
}

// UserFromContext retrieves the authenticated user.
func UserFromContext(ctx context.Context) (*user.User, bool) {
	u, ok := ctx.Value(userContextKey).(*user.User)
	return u, ok
}
