package server

import (
	"database/sql"
	"net/http"
	"time"

	"github.com/go-chi/chi/v5"
	chimiddleware "github.com/go-chi/chi/v5/middleware"

	"github.com/escape-all/cyber-lms/internal/health"
	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/auth"
	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/lesson"
	"github.com/escape-all/cyber-lms/pkg/progress"
	"github.com/escape-all/cyber-lms/pkg/quiz"
	"github.com/escape-all/cyber-lms/pkg/tenant" // Import the tenant package
)

// Dependencies captures services shared between handlers.
type Dependencies struct {
	DB            *sql.DB
	AuthService   *auth.Service
	CourseStore   *course.Store
	LessonStore   *lesson.Store
	ProgressStore *progress.ProgressStore
	QuizStore     *quiz.Store
	TenantStore   *tenant.Store // Add TenantStore
}

// NewRouter builds the HTTP handler chain for the API surface.
func NewRouter(deps Dependencies) http.Handler {
	r := chi.NewRouter()
	r.Use(chimiddleware.RequestID)
	r.Use(chimiddleware.RealIP)
	r.Use(chimiddleware.Logger)
	r.Use(chimiddleware.Recoverer)
	r.Use(chimiddleware.Timeout(10 * time.Second))

	r.Get("/health", health.Handle)
	r.Get("/ready", health.Ready(deps.DB))

	courseHandlers := newCourseHandlers(deps.CourseStore)
	authHandlers := newAuthHandlers(deps.AuthService, deps.TenantStore) // Pass TenantStore to authHandlers
	lessonHandlers := newLessonHandlers(deps.LessonStore, deps.CourseStore)
	progressHandlers := newProgressHandlers(deps.ProgressStore, deps.CourseStore, deps.LessonStore)
	quizHandlers := newQuizHandlers(deps.QuizStore, deps.LessonStore, deps.CourseStore, deps.ProgressStore)
	tenantHandlers := newTenantHandlers(deps.TenantStore)

	r.Get("/courses", courseHandlers.ListCourses)
	r.Get("/courses/{id}", courseHandlers.GetCourse)
	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(deps.AuthService))
		r.Get("/courses/{id}/lessons", lessonHandlers.ListLessons)
		r.Get("/lessons/{id}", lessonHandlers.GetLesson)
		r.Post("/lessons/{id}/complete", progressHandlers.markLessonComplete)
		r.Get("/courses/{id}/progress", progressHandlers.userCourseProgress)
		r.Get("/lessons/{id}/quiz", quizHandlers.GetLessonQuiz)
		r.Post("/quizzes/{id}/attempts", quizHandlers.SubmitQuiz)
	})

	r.Route("/auth", func(r chi.Router) {
		r.Post("/register", authHandlers.Register)
		r.Post("/login", authHandlers.Login)

		r.Group(func(r chi.Router) {
			r.Use(middleware.Auth(deps.AuthService))
			r.Post("/logout", authHandlers.Logout)
			r.Get("/me", authHandlers.Me)
		})
	})

	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(deps.AuthService))

		r.Route("/dashboard", func(r chi.Router) {
			r.With(middleware.RequireRoles("learner", "instructor", "admin")).Get("/learner", learnerDashboard)
			r.With(middleware.RequireRoles("instructor", "admin")).Get("/instructor", instructorDashboard)
		})

		r.Route("/me", func(r chi.Router) {
			r.Get("/enrollments", courseHandlers.MyEnrollments)
		})

		r.Post("/courses/{id}/enroll", courseHandlers.Enroll)
		r.Post("/courses/{id}/lessons", lessonHandlers.CreateLesson)
		r.Put("/lessons/{id}", lessonHandlers.UpdateLesson)
	})

	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(deps.AuthService))
		r.With(middleware.RequireRoles("instructor", "admin")).Post("/courses", courseHandlers.CreateCourse)
		r.With(middleware.RequireRoles("instructor", "admin")).Put("/courses/{id}", courseHandlers.UpdateCourse)
		r.With(middleware.RequireRoles("instructor", "admin")).Get("/instructor/courses/{id}/progress", progressHandlers.instructorCourseProgress)
		r.With(middleware.RequireRoles("instructor", "admin")).Post("/lessons/{id}/quiz", quizHandlers.CreateLessonQuiz)
		r.With(middleware.RequireRoles("instructor", "admin")).Get("/instructor/courses/{id}/report", quizHandlers.InstructorReport)
	})

	r.Group(func(r chi.Router) {
		r.Use(middleware.Auth(deps.AuthService))
		r.With(middleware.RequireRoles("admin")).Post("/tenants", tenantHandlers.CreateTenant)
	})

	return r
}
