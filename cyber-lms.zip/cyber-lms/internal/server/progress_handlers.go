package server

import (
	"errors"
	"net/http"

	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/lesson"
	"github.com/escape-all/cyber-lms/pkg/progress"
)

type progressHandlers struct {
	progressStore *progress.ProgressStore
	courseStore   *course.Store
	lessonStore   *lesson.Store
}

func newProgressHandlers(ps *progress.ProgressStore, cs *course.Store, ls *lesson.Store) *progressHandlers {
	return &progressHandlers{
		progressStore: ps,
		courseStore:   cs,
		lessonStore:   ls,
	}
}

type courseProgressResponse struct {
	CompletedLessons []int64 `json:"completed_lessons"`
	Completed        int     `json:"completed"`
	Total            int     `json:"total"`
	Percent          int     `json:"percent"`
}

type instructorProgressResponse struct {
	TotalLessons      int     `json:"total_lessons"`
	TotalUsers        int     `json:"total_users"`
	CompletedLessons  int     `json:"completed_lessons"`
	AverageCompletion float64 `json:"average_completion"`
}

func (h *progressHandlers) markLessonComplete(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	lessonID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid lesson id", http.StatusBadRequest)
		return
	}

	lessonObj, err := h.lessonStore.GetByID(r.Context(), lessonID, user.TenantID)
	if err != nil {
		if errors.Is(err, lesson.ErrNotFound) {
			http.Error(w, "lesson not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve lesson", http.StatusInternalServerError)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), lessonObj.CourseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve course", http.StatusInternalServerError)
		return
	}

	okAccess, err := lessonAccessAllowed(r.Context(), h.courseStore, user, courseObj.ID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to verify access", http.StatusInternalServerError)
		return
	}
	if !okAccess {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	if err := h.progressStore.MarkComplete(r.Context(), user.ID, lessonID, user.TenantID); err != nil {
		http.Error(w, "unable to record completion", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, map[string]string{"status": "completed"})
}

func (h *progressHandlers) userCourseProgress(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courseID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	completedMap, err := h.progressStore.CompletedLessons(r.Context(), user.ID, courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to read progress", http.StatusInternalServerError)
		return
	}

	completed, total, err := h.progressStore.CourseProgress(r.Context(), user.ID, courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to read progress summary", http.StatusInternalServerError)
		return
	}

	percent := 0
	if total > 0 {
		percent = (completed * 100) / total
	}

	response := courseProgressResponse{
		CompletedLessons: mapKeys(completedMap),
		Completed:        completed,
		Total:            total,
		Percent:          percent,
	}

	respondJSON(w, http.StatusOK, response)
}

func (h *progressHandlers) instructorCourseProgress(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courseID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), courseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve course", http.StatusInternalServerError)
		return
	}

	if !lessonAccessAllowedForInstructor(user, courseObj) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	totalLessons, err := h.lessonStore.CountByCourse(r.Context(), courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to count lessons", http.StatusInternalServerError)
		return
	}

	completedLessons, totalUsers, err := h.progressStore.InstructorProgress(r.Context(), courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to compute progress", http.StatusInternalServerError)
		return
	}

	averageCompletion := 0.0
	if totalUsers > 0 && totalLessons > 0 {
		averageCompletion = float64(completedLessons) / float64(totalUsers*totalLessons) * 100
	}

	response := instructorProgressResponse{
		TotalLessons:      totalLessons,
		TotalUsers:        totalUsers,
		CompletedLessons:  completedLessons,
		AverageCompletion: averageCompletion,
	}

	respondJSON(w, http.StatusOK, response)
}
