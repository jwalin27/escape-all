package server

import (
	"encoding/json"
	"errors"
	"net/http"

	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/auth"
	"github.com/escape-all/cyber-lms/pkg/tenant"
)

type authHandlers struct {
	authService *auth.Service
	tenantStore *tenant.Store
}

func newAuthHandlers(authService *auth.Service, tenantStore *tenant.Store) *authHandlers {
	return &authHandlers{authService: authService, tenantStore: tenantStore}
}

type registerRequest struct {
	Email      string `json:"email"`
	Password   string `json:"password"`
	Role       string `json:"role"`
	TenantName string `json:"tenant_name"` // Add TenantName field
}

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func (h *authHandlers) Register(w http.ResponseWriter, r *http.Request) {
	var req registerRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request payload", http.StatusBadRequest)
		return
	}

	// Find or create tenant
	var currentTenant *tenant.Tenant
	if req.TenantName != "" {
		// In a real app, you'd likely have a way to find an existing tenant or more robust tenant creation logic.
		// For now, we'll create a new tenant if the name is provided.
		var err error
		currentTenant, err = h.tenantStore.Create(r.Context(), req.TenantName)
		if err != nil {
			http.Error(w, "unable to create tenant", http.StatusInternalServerError)
			return
		}
	} else {
		// Default to a "default" tenant for simplicity if no tenant name is provided
		// In a real B2B app, this flow would be more defined.
		http.Error(w, "tenant_name is required", http.StatusBadRequest)
		return
	}

	resp, err := h.authService.Register(r.Context(), req.Email, req.Password, req.Role, currentTenant.ID) // Pass tenantID
	if err != nil {
		if errors.Is(err, auth.ErrDuplicateUser) {
			http.Error(w, "email already registered", http.StatusConflict)
			return
		}
		if errors.Is(err, auth.ErrInvalidCredentials) {
			http.Error(w, "invalid credentials", http.StatusBadRequest)
			return
		}
		http.Error(w, "registration failed", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusCreated, resp)
}

func (h *authHandlers) Login(w http.ResponseWriter, r *http.Request) {
	var req loginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request payload", http.StatusBadRequest)
		return
	}

	resp, err := h.authService.Login(r.Context(), req.Email, req.Password)
	if err != nil {
		if errors.Is(err, auth.ErrInvalidCredentials) {
			http.Error(w, "invalid credentials", http.StatusUnauthorized)
			return
		}
		http.Error(w, "authentication failed", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, resp)
}

func (h *authHandlers) Logout(w http.ResponseWriter, _ *http.Request) {
	respondJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}

func (h *authHandlers) Me(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "not authenticated", http.StatusUnauthorized)
		return
	}

	respondJSON(w, http.StatusOK, auth.AuthUser{
		ID:    user.ID,
		Email: user.Email,
		Role:  user.Role,
	})
}
