package server

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strings"

	"github.com/google/uuid"

	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/lesson"
	"github.com/escape-all/cyber-lms/pkg/user"
)

type lessonHandlers struct {
	lessonStore *lesson.Store
	courseStore *course.Store
}

func newLessonHandlers(ls *lesson.Store, cs *course.Store) *lessonHandlers {
	return &lessonHandlers{
		lessonStore: ls,
		courseStore: cs,
	}
}

type lessonPayload struct {
	Title       string `json:"title"`
	LessonType  string `json:"lesson_type"`
	ContentURL  string `json:"content_url"`
	ContentText string `json:"content_text"`
	OrderIndex  int    `json:"order_index"`
}

func (h *lessonHandlers) CreateLesson(w http.ResponseWriter, r *http.Request) {
	var payload lessonPayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courseID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), courseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve course", http.StatusInternalServerError)
		return
	}

	if !h.canManageCourse(courseObj, user) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	order := payload.OrderIndex
	if order <= 0 {
		lessons, _ := h.lessonStore.ListByCourse(r.Context(), courseID, user.TenantID)
		order = len(lessons) + 1
	}

	created, err := h.lessonStore.Create(r.Context(), courseID, payload.Title, payload.LessonType, payload.ContentURL, payload.ContentText, order, user.TenantID)
	if err != nil {
		http.Error(w, "unable to create lesson", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusCreated, created)
}

func (h *lessonHandlers) UpdateLesson(w http.ResponseWriter, r *http.Request) {
	var payload lessonPayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	id, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid lesson id", http.StatusBadRequest)
		return
	}

	existing, err := h.lessonStore.GetByID(r.Context(), id, user.TenantID)
	if err != nil {
		if errors.Is(err, lesson.ErrNotFound) {
			http.Error(w, "lesson not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve lesson", http.StatusInternalServerError)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), existing.CourseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to resolve course", http.StatusInternalServerError)
		return
	}

	if !h.canManageCourse(courseObj, user) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	order := payload.OrderIndex
	if order <= 0 {
		order = existing.OrderIndex
	}

	updated, err := h.lessonStore.Update(r.Context(), id, payload.Title, payload.LessonType, payload.ContentURL, payload.ContentText, order, user.TenantID)
	if err != nil {
		http.Error(w, "unable to update lesson", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, updated)
}

func (h *lessonHandlers) ListLessons(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courseID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	okAccess, err := h.canAccessCourse(r.Context(), user, courseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to retrieve course", http.StatusInternalServerError)
		return
	}
	if !okAccess {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	lessons, err := h.lessonStore.ListByCourse(r.Context(), courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to list lessons", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, lessons)
}

func (h *lessonHandlers) GetLesson(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	id, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid lesson id", http.StatusBadRequest)
		return
	}

	lessonObj, err := h.lessonStore.GetByID(r.Context(), id, user.TenantID)
	if err != nil {
		if errors.Is(err, lesson.ErrNotFound) {
			http.Error(w, "lesson not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve lesson", http.StatusInternalServerError)
		return
	}

	okAccess, err := h.canAccessCourse(r.Context(), user, lessonObj.CourseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to verify access", http.StatusInternalServerError)
		return
	}
	if !okAccess {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	respondJSON(w, http.StatusOK, lessonObj)
}

func (h *lessonHandlers) canManageCourse(courseObj *course.Course, user *user.User) bool {
	if strings.EqualFold(user.Role, "admin") {
		return true
	}
	if strings.EqualFold(user.Role, "instructor") && courseObj.InstructorID == user.ID {
		return true
	}
	return false
}

func (h *lessonHandlers) canAccessCourse(ctx context.Context, user *user.User, courseID int64, tenantID uuid.UUID) (bool, error) {
	if strings.EqualFold(user.Role, "admin") {
		return true, nil
	}

	courseObj, err := h.courseStore.GetByID(ctx, courseID, tenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			return false, err
		}
		return false, err
	}

	if strings.EqualFold(user.Role, "instructor") && courseObj.InstructorID == user.ID {
		return true, nil
	}

	enrolled, err := h.courseStore.IsEnrolled(ctx, user.ID, courseID, tenantID)
	if err != nil {
		return false, err
	}

	return enrolled, nil
}
