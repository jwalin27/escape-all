package server

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"

	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/course"
)

type courseHandlers struct {
	store *course.Store
}

func newCourseHandlers(store *course.Store) *courseHandlers {
	return &courseHandlers{store: store}
}

type coursePayload struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	Published   bool   `json:"published"`
}

func (h *courseHandlers) CreateCourse(w http.ResponseWriter, r *http.Request) {
	var payload coursePayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	c, err := h.store.Create(r.Context(), payload.Title, payload.Description, payload.Published, user.ID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to create course", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusCreated, c)
}

func (h *courseHandlers) UpdateCourse(w http.ResponseWriter, r *http.Request) {
	var payload coursePayload
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	id, err := strconv.ParseInt(chi.URLParam(r, "id"), 10, 64)
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	courseObj, err := h.store.Update(r.Context(), id, user.ID, payload.Title, payload.Description, payload.Published, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to update course", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, courseObj)
}

func (h *courseHandlers) ListCourses(w http.ResponseWriter, r *http.Request) {
	search := r.URL.Query().Get("q")
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		// If no user is authenticated, we can return all public courses
		// or handle it as an unauthorized request depending on business logic.
		// For now, let's assume public courses should not be filtered by tenant.
		// This needs to be carefully considered.
		// For tenant-aware listing, an anonymous user should not see anything.
		// For now, let's make it return an error if no user/tenant is in context.
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courses, err := h.store.List(r.Context(), user.TenantID, search)
	if err != nil {
		http.Error(w, "unable to load courses", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, courses)
}

func (h *courseHandlers) GetCourse(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(chi.URLParam(r, "id"), 10, 64)
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	found, err := h.store.GetByID(r.Context(), id, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to load course", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, found)
}

func (h *courseHandlers) Enroll(w http.ResponseWriter, r *http.Request) {
	id, err := strconv.ParseInt(chi.URLParam(r, "id"), 10, 64)
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	enrollment, err := h.store.Enroll(r.Context(), user.ID, id, user.TenantID)
	if err != nil {
		http.Error(w, "unable to enroll", http.StatusInternalServerError)
		return
	}

	if enrollment == nil {
		respondJSON(w, http.StatusOK, map[string]string{"status": "already enrolled"})
		return
	}

	respondJSON(w, http.StatusCreated, enrollment)
}

func (h *courseHandlers) MyEnrollments(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courses, err := h.store.ListEnrollments(r.Context(), user.ID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to list enrollments", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusOK, courses)
}
