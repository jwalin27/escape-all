package server

import (
	"encoding/json"
	"errors"
	"net/http"
	"time"

	"github.com/escape-all/cyber-lms/internal/middleware"
	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/lesson"
	"github.com/escape-all/cyber-lms/pkg/progress"
	"github.com/escape-all/cyber-lms/pkg/quiz"
)

type quizHandlers struct {
	quizStore     *quiz.Store
	lessonStore   *lesson.Store
	courseStore   *course.Store
	progressStore *progress.ProgressStore
}

func newQuizHandlers(qs *quiz.Store, ls *lesson.Store, cs *course.Store, ps *progress.ProgressStore) *quizHandlers {
	return &quizHandlers{
		quizStore:     qs,
		lessonStore:   ls,
		courseStore:   cs,
		progressStore: ps,
	}
}

type questionPayload struct {
	Prompt       string   `json:"prompt"`
	Choices      []string `json:"choices"`
	CorrectIndex int      `json:"correct_index"`
	OrderIndex   int      `json:"order_index"`
}

type createQuizRequest struct {
	Title     string            `json:"title"`
	Questions []questionPayload `json:"questions"`
}

type answerPayload struct {
	QuestionID    int64 `json:"question_id"`
	SelectedIndex int   `json:"selected_index"`
}

type submitAttemptRequest struct {
	Answers []answerPayload `json:"answers"`
}

type quizResponse struct {
	ID        int64              `json:"id"`
	LessonID  int64              `json:"lesson_id"`
	Title     string             `json:"title"`
	CreatedAt string             `json:"created_at"`
	Questions []questionResponse `json:"questions"`
}

type questionResponse struct {
	ID         int64    `json:"id"`
	Prompt     string   `json:"prompt"`
	Choices    []string `json:"choices"`
	OrderIndex int      `json:"order_index"`
}

type attemptResponse struct {
	Score int `json:"score"`
	Total int `json:"total"`
}

type instructorReportResponse struct {
	Enrolled         int     `json:"enrolled"`
	CompletionPct    int     `json:"completion_pct"`
	AverageScore     float64 `json:"average_score"`
	TotalLessons     int     `json:"total_lessons"`
	CompletedEntries int     `json:"completed_entries"`
}

func (h *quizHandlers) CreateLessonQuiz(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	lessonID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid lesson id", http.StatusBadRequest)
		return
	}

	lessonObj, err := h.lessonStore.GetByID(r.Context(), lessonID, user.TenantID)
	if err != nil {
		if errors.Is(err, lesson.ErrNotFound) {
			http.Error(w, "lesson not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to load lesson", http.StatusInternalServerError)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), lessonObj.CourseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to resolve course", http.StatusInternalServerError)
		return
	}

	if !lessonAccessAllowedForInstructor(user, courseObj) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	var payload createQuizRequest
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	if len(payload.Questions) == 0 {
		http.Error(w, "at least one question required", http.StatusBadRequest)
		return
	}

	questions := make([]quiz.Question, len(payload.Questions))
	for i, q := range payload.Questions {
		questions[i] = quiz.Question{
			Prompt:       q.Prompt,
			Choices:      q.Choices,
			CorrectIndex: q.CorrectIndex,
			OrderIndex:   q.OrderIndex,
		}
	}

	result, err := h.quizStore.CreateQuiz(r.Context(), lessonID, payload.Title, questions, user.TenantID)
	if err != nil {
		http.Error(w, "unable to create quiz", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusCreated, quizResponse{
		ID:        result.ID,
		LessonID:  result.LessonID,
		Title:     result.Title,
		CreatedAt: result.CreatedAt.Format(time.RFC3339),
	})
}

func (h *quizHandlers) GetLessonQuiz(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	lessonID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid lesson id", http.StatusBadRequest)
		return
	}

	lessonObj, err := h.lessonStore.GetByID(r.Context(), lessonID, user.TenantID)
	if err != nil {
		if errors.Is(err, lesson.ErrNotFound) {
			http.Error(w, "lesson not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to load lesson", http.StatusInternalServerError)
		return
	}

	if ok, err := lessonAccessAllowed(r.Context(), h.courseStore, user, lessonObj.CourseID, user.TenantID); err != nil || !ok {
		if err != nil {
			http.Error(w, "unable to verify access", http.StatusInternalServerError)
			return
		}
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	quizObj, err := h.quizStore.GetQuizByLesson(r.Context(), lessonID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to load quiz", http.StatusInternalServerError)
		return
	}
	if quizObj == nil {
		http.Error(w, "quiz not found", http.StatusNotFound)
		return
	}

	resp := quizResponse{
		ID:        quizObj.ID,
		LessonID:  lessonID,
		Title:     quizObj.Title,
		CreatedAt: quizObj.CreatedAt.Format(time.RFC3339),
	}
	for _, q := range quizObj.Questions {
		resp.Questions = append(resp.Questions, questionResponse{
			ID:         q.ID,
			Prompt:     q.Prompt,
			Choices:    q.Choices,
			OrderIndex: q.OrderIndex,
		})
	}

	respondJSON(w, http.StatusOK, resp)
}

func (h *quizHandlers) SubmitQuiz(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	quizID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid quiz id", http.StatusBadRequest)
		return
	}

	var payload submitAttemptRequest
	if err := json.NewDecoder(r.Body).Decode(&payload); err != nil {
		http.Error(w, "invalid payload", http.StatusBadRequest)
		return
	}

	attempt := make([]quiz.Answer, len(payload.Answers))
	for i, ans := range payload.Answers {
		attempt[i] = quiz.Answer{
			QuestionID:    ans.QuestionID,
			SelectedIndex: ans.SelectedIndex,
		}
	}

	result, err := h.quizStore.SubmitAttempt(r.Context(), quizID, user.ID, attempt, user.TenantID)
	if err != nil {
		http.Error(w, "unable to grade quiz", http.StatusInternalServerError)
		return
	}

	questionCount := len(payload.Answers)
	if questionCount == 0 {
		questionCount = len(result.Answers)
	}

	respondJSON(w, http.StatusOK, attemptResponse{
		Score: result.Score,
		Total: questionCount,
	})
}

func (h *quizHandlers) InstructorReport(w http.ResponseWriter, r *http.Request) {
	user, ok := middleware.UserFromContext(r.Context())
	if !ok {
		http.Error(w, "authentication required", http.StatusUnauthorized)
		return
	}

	courseID, err := parseIDParam(r, "id")
	if err != nil {
		http.Error(w, "invalid course id", http.StatusBadRequest)
		return
	}

	courseObj, err := h.courseStore.GetByID(r.Context(), courseID, user.TenantID)
	if err != nil {
		if errors.Is(err, course.ErrNotFound) {
			http.Error(w, "course not found", http.StatusNotFound)
			return
		}
		http.Error(w, "unable to load course", http.StatusInternalServerError)
		return
	}

	if !lessonAccessAllowedForInstructor(user, courseObj) {
		http.Error(w, "forbidden", http.StatusForbidden)
		return
	}

	completedEntries, totalLessons, totalUsers, err := h.progressStore.CourseCompletionStats(r.Context(), courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to compute completion", http.StatusInternalServerError)
		return
	}

	_, avgScore, err := h.quizStore.InstructorReport(r.Context(), courseID, user.TenantID)
	if err != nil {
		http.Error(w, "unable to compute score", http.StatusInternalServerError)
		return
	}

	var completionPct int
	if totalLessons > 0 && totalUsers > 0 {
		completionPct = (completedEntries * 100) / (totalLessons * totalUsers)
	}

	resp := instructorReportResponse{
		Enrolled:         totalUsers,
		CompletionPct:    completionPct,
		AverageScore:     float64(avgScore),
		TotalLessons:     totalLessons,
		CompletedEntries: completedEntries,
	}

	respondJSON(w, http.StatusOK, resp)
}
