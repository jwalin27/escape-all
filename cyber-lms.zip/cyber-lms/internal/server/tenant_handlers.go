package server

import (
	"encoding/json"
	"net/http"

	"github.com/escape-all/cyber-lms/pkg/tenant"
)

type tenantHandlers struct {
	store *tenant.Store
}

func newTenantHandlers(store *tenant.Store) *tenantHandlers {
	return &tenantHandlers{store: store}
}

type createTenantRequest struct {
	Name string `json:"name"`
}

func (h *tenantHandlers) CreateTenant(w http.ResponseWriter, r *http.Request) {
	var req createTenantRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request payload", http.StatusBadRequest)
		return
	}

	t, err := h.store.Create(r.Context(), req.Name)
	if err != nil {
		http.Error(w, "unable to create tenant", http.StatusInternalServerError)
		return
	}

	respondJSON(w, http.StatusCreated, t)
}
