package server

import (
	"context"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"

	"github.com/escape-all/cyber-lms/pkg/course"
	"github.com/escape-all/cyber-lms/pkg/user"
)

func parseIDParam(r *http.Request, key string) (int64, error) {
	return strconv.ParseInt(chi.URLParam(r, key), 10, 64)
}

func lessonAccessAllowed(ctx context.Context, courseStore *course.Store, user *user.User, courseID int64, tenantID uuid.UUID) (bool, error) {
	if strings.EqualFold(user.Role, "admin") {
		return true, nil
	}

	courseObj, err := courseStore.GetByID(ctx, courseID, tenantID)
	if err != nil {
		return false, err
	}

	if strings.EqualFold(user.Role, "instructor") && courseObj.InstructorID == user.ID {
		return true, nil
	}

	return courseStore.IsEnrolled(ctx, user.ID, courseID, tenantID)
}

func lessonAccessAllowedForInstructor(user *user.User, courseObj *course.Course) bool {
	if strings.EqualFold(user.Role, "admin") {
		return true
	}
	return strings.EqualFold(user.Role, "instructor") && courseObj.InstructorID == user.ID
}

func mapKeys(src map[int64]time.Time) []int64 {
	keys := make([]int64, 0, len(src))
	for k := range src {
		keys = append(keys, k)
	}
	return keys
}
