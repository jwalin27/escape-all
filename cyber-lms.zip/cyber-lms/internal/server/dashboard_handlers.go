package server

import (
	"fmt"
	"net/http"

	"github.com/escape-all/cyber-lms/internal/middleware"
)

func learnerDashboard(w http.ResponseWriter, r *http.Request) {
	user, _ := middleware.UserFromContext(r.Context())
	message := fmt.Sprintf("Learner dashboard — welcome back %s (%s)", user.Email, user.Role)
	respondJSON(w, http.StatusOK, map[string]string{"message": message})
}

func instructorDashboard(w http.ResponseWriter, r *http.Request) {
	user, _ := middleware.UserFromContext(r.Context())
	message := fmt.Sprintf("Instructor dashboard — empowered view for %s", user.Email)
	respondJSON(w, http.StatusOK, map[string]string{"message": message})
}
